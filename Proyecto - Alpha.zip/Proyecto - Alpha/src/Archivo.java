
public class Archivo
{

}
