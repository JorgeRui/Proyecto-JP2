package view;

import javax.swing.JInternalFrame;

public class VentanaEstadisticas extends JInternalFrame
{
	private static final long serialVersionUID = 1L;
	static int ventanasAbiertas = 0;
	static final int posicionX  = 30, posicionY  = 30;

	public VentanaEstadisticas()
	{
		super("Documento #" + (++ventanasAbiertas), true, true, true, true);
	    setLocation(posicionX*ventanasAbiertas, posicionY*ventanasAbiertas);
	    
		setSize(400,400);
	    setVisible(true);
	}
	
	public void crearVentana()
	{
		
	}
}
