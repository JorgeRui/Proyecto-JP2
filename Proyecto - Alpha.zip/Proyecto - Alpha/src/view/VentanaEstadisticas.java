package view;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JTextField;
import javax.swing.SpringLayout;


public class VentanaEstadisticas extends JFrame {
	
	SpringLayout sp;
	JLabel moda, mediana, media, desviacionMedia, varianza, desviacionTipica, coeficienteCorrelacion, cuartiles, deciles, percentiles;
	JLabel etiquetaModa, etiquetaMediana, etiquetaMedia, etiquetaDesviacionMedia, etiquetaVarianza, etiquetaDesviacionTipica, etiquetaCoeficienteCorrelacion, etiquetaCuartiles, etiquetaDeciles, etiquetaPercentiles;
	private static final long serialVersionUID = 1L;


	public VentanaEstadisticas() {
		super();
	   
		
		this.setBounds(20, 100 , 440, 460);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	
	}
	
	public void crearVentana() {
		
		this.sp = new SpringLayout();
		this.setLayout(this.sp);
		
		this.etiquetaModa= new JLabel ("Moda");
		this.etiquetaMediana= new JLabel ("Mediana");
		this.etiquetaMedia= new JLabel ("Media");
		this.etiquetaDesviacionMedia= new JLabel ("Desviacion media");
		this.etiquetaVarianza= new JLabel ("Varianza");
		this.etiquetaDesviacionTipica= new JLabel ("Desviacion tipica");
		this.etiquetaCoeficienteCorrelacion= new JLabel ("Coeficiente de Correlacion");
		this.etiquetaCuartiles= new JLabel ("Cuartiles");
		this.etiquetaDeciles= new JLabel ("Deciles");
		this.etiquetaPercentiles= new JLabel ("Percentiles");
		
		
		this.moda= new JLabel ("r1");		
		this.mediana= new JLabel ("r2");		
		this.media= new JLabel ("r3");		
		this.desviacionMedia= new JLabel ("r4");		
		this.varianza= new JLabel ("r5");		
		this.desviacionTipica= new JLabel ("r6");		
		this.coeficienteCorrelacion= new JLabel ("r7");		
		this.cuartiles= new JLabel ("r8");	
		this.deciles= new JLabel ("r9");		
		this.percentiles= new JLabel ("r10");		


		this.add(this.etiquetaModa);
		this.add(this.etiquetaMediana);
		this.add(this.etiquetaMedia);
		this.add(this.etiquetaDesviacionMedia);
		this.add(this.etiquetaVarianza);
		this.add(this.etiquetaDesviacionTipica);
		this.add(this.etiquetaCoeficienteCorrelacion);
		this.add(this.etiquetaCuartiles);
		this.add(this.etiquetaDeciles);
		this.add(this.etiquetaPercentiles);
		
		this.add(this.moda);
		this.add(this.mediana);
		this.add(this.media);
		this.add(this.desviacionMedia);
		this.add(this.varianza);
		this.add(this.desviacionTipica);
		this.add(this.coeficienteCorrelacion);
		this.add(this.cuartiles);
		this.add(this.deciles);
		this.add(this.percentiles);

		//ETIQUETAS
		 sp.putConstraint(SpringLayout.NORTH, this.etiquetaModa, 60, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.etiquetaModa, 30, SpringLayout.WEST, this.getContentPane());
		 
		 sp.putConstraint(SpringLayout.NORTH, this.etiquetaMediana, 90, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.etiquetaMediana, 30, SpringLayout.WEST, this.getContentPane());
		 
		 sp.putConstraint(SpringLayout.NORTH, this.etiquetaMedia, 120, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.etiquetaMedia, 30, SpringLayout.WEST, this.getContentPane());
		
		 sp.putConstraint(SpringLayout.NORTH, this.etiquetaDesviacionMedia, 150, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.etiquetaDesviacionMedia, 30, SpringLayout.WEST, this.getContentPane());
		 
		 sp.putConstraint(SpringLayout.NORTH, this.etiquetaVarianza, 180, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.etiquetaVarianza, 30, SpringLayout.WEST, this.getContentPane());
		 
		 sp.putConstraint(SpringLayout.NORTH, this.etiquetaDesviacionTipica, 210, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.etiquetaDesviacionTipica, 30, SpringLayout.WEST, this.getContentPane());
		 
		 sp.putConstraint(SpringLayout.NORTH, this.etiquetaCoeficienteCorrelacion, 240, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.etiquetaCoeficienteCorrelacion, 30, SpringLayout.WEST, this.getContentPane());
		 
		 sp.putConstraint(SpringLayout.NORTH, this.etiquetaCuartiles, 270, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.etiquetaCuartiles, 30, SpringLayout.WEST, this.getContentPane());
		 
		 sp.putConstraint(SpringLayout.NORTH, this.etiquetaDeciles, 300, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.etiquetaDeciles, 30, SpringLayout.WEST, this.getContentPane());
		 
		 sp.putConstraint(SpringLayout.NORTH, this.etiquetaPercentiles, 330, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.etiquetaPercentiles, 30, SpringLayout.WEST, this.getContentPane());
		 
		 
		 //TEXTFIELD
		 
		 sp.putConstraint(SpringLayout.NORTH, this.moda, 55, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.moda, 200, SpringLayout.WEST, this.getContentPane());
		 
		 sp.putConstraint(SpringLayout.NORTH, this.mediana, 85, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.mediana, 200, SpringLayout.WEST, this.getContentPane());
		 
		 sp.putConstraint(SpringLayout.NORTH, this.media, 115, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.media, 200, SpringLayout.WEST, this.getContentPane());
		
		 sp.putConstraint(SpringLayout.NORTH, this.desviacionMedia, 145, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.desviacionMedia, 200, SpringLayout.WEST, this.getContentPane());
		 
		 sp.putConstraint(SpringLayout.NORTH, this.varianza, 175, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.varianza, 200, SpringLayout.WEST, this.getContentPane());
		 
		 sp.putConstraint(SpringLayout.NORTH, this.desviacionTipica, 205, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.desviacionTipica, 200, SpringLayout.WEST, this.getContentPane());
		 
		 sp.putConstraint(SpringLayout.NORTH, this.coeficienteCorrelacion, 235, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.coeficienteCorrelacion, 200, SpringLayout.WEST, this.getContentPane());
		 
		 sp.putConstraint(SpringLayout.NORTH, this.cuartiles, 265, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.cuartiles, 200, SpringLayout.WEST, this.getContentPane());
		 
		 sp.putConstraint(SpringLayout.NORTH, this.deciles, 295, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.deciles, 200, SpringLayout.WEST, this.getContentPane());
		 
		 sp.putConstraint(SpringLayout.NORTH, this.percentiles, 325, SpringLayout.NORTH, this.getContentPane());
		 sp.putConstraint(SpringLayout.WEST, this.percentiles, 200, SpringLayout.WEST, this.getContentPane());
		 
		 
		 setVisible(true);

	}
}
