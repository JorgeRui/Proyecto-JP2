package view;

import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;


public class VentanaEstadisticas extends JFrame
{
	JLabel titulo;
	private static final long serialVersionUID = 1L;


	public VentanaEstadisticas() {
		super();
	   
		
		this.setBounds(20, 100 , 440, 460);
		this.setDefaultCloseOperation(JFrame.DISPOSE_ON_CLOSE);
		
	
	}
	
	public void crearVentana() {
		this.titulo= new JLabel ("Prueba");
	
			
		this.add(this.titulo);
		setVisible(true);

	}
}
