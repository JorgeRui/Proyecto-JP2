package view;

import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;


public class VentanaEstadisticas extends JInternalFrame
{
	
	private static final long serialVersionUID = 1L;
	
	JLabel modaX, medianaX, mediaX, desviacionMediaX, varianzaX, desviacionTipicaX, coeficienteCorrelacionX, modaY, medianaY, mediaY, desviacionMediaY, varianzaY, desviacionTipicaY, coeficienteCorrelacionY;

	public JLabel getModaX(){
		return modaX;
	}

	public JLabel getMedianaX()
	{
		return medianaX;
	}

	public JLabel getMediaX()
	{
		return mediaX;
	}

	public JLabel getDesviacionMediaX()
	{
		return desviacionMediaX;
	}

	public JLabel getVarianzaX()
	{
		return varianzaX;
	}

	public JLabel getDesviacionTipicaX()
	{
		return desviacionTipicaX;
	}

	public JLabel getCoeficienteCorrelacionX()
	{
		return coeficienteCorrelacionX;
	}
	
	
	
	
	public JLabel getModaY(){
		return modaY;
	}

	public JLabel getMedianaY(){
		return medianaY;
	}

	public JLabel getMediaY(){
		return mediaY;
	}

	public JLabel getDesviacionMediaY(){
		return desviacionMediaY;
	}

	public JLabel getVarianzaY(){
		return varianzaY;
	}

	public JLabel getDesviacionTipicaY(){
		return desviacionTipicaY;
	}

	public JLabel getCoeficienteCorrelacionY(){
		return coeficienteCorrelacionY;
	}
	
	
	
	//SET
	
	public void setModaX(JLabel modaX) {
		this.modaX = modaX;
	}

	public void setMedianaX(JLabel medianaX) {
		this.medianaX = medianaX;
	}

	public void setMediaX(JLabel mediaX) {
		this.mediaX = mediaX;
	}

	public void setDesviacionMediaX(JLabel desviacionMediaX) {
		this.desviacionMediaX = desviacionMediaX;
	}

	public void setVarianzaX(JLabel varianzaX) {
		this.varianzaX = varianzaX;
	}

	public void setDesviacionTipicaX(JLabel desviacionTipicaX) {
		this.desviacionTipicaX = desviacionTipicaX;
	}

	public void setCoeficienteCorrelacionX(JLabel coeficienteCorrelacionX) {
		this.coeficienteCorrelacionX = coeficienteCorrelacionX;
	}

	public void setModaY(JLabel modaY) {
		this.modaY = modaY;
	}

	public void setMedianaY(JLabel medianaY) {
		this.medianaY = medianaY;
	}

	public void setMediaY(JLabel mediaY) {
		this.mediaY = mediaY;
	}

	public void setDesviacionMediaY(JLabel desviacionMediaY) {
		this.desviacionMediaY = desviacionMediaY;
	}

	public void setVarianzaY(JLabel varianzaY) {
		this.varianzaY = varianzaY;
	}

	public void setDesviacionTipicaY(JLabel desviacionTipicaY) {
		this.desviacionTipicaY = desviacionTipicaY;
	}

	public void setCoeficienteCorrelacionY(JLabel coeficienteCorrelacionY) {
		this.coeficienteCorrelacionY = coeficienteCorrelacionY;
	}
	
	
	//////////////////////////////////////////////////////////////////////////////////////
	
	
	public VentanaEstadisticas() {
		super("Estadisticas", true, true, true, true);
	   
		try{
			
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
			
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException error) 
		{
			System.err.println("Error en clase VentanaPrincipal - Constructor");
		}
		setSize(800,350);
		setBounds(20, 100 , 440, 460);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		crearVentana();
	}
	
	

	public void crearVentana(){
		JLabel etiquetaModa, etiquetaMediana, etiquetaMedia, etiquetaDesviacionMedia, etiquetaVarianza, etiquetaDesviacionTipica, etiquetaCoeficienteCorrelacion;
	
		GridLayout gl;
		gl = new GridLayout(7,3);
		setLayout(gl);
		
		etiquetaModa					= new JLabel ("Moda", JLabel.CENTER);
		etiquetaMediana					= new JLabel ("Mediana", JLabel.CENTER);
		etiquetaMedia					= new JLabel ("Media", JLabel.CENTER);
		etiquetaDesviacionMedia			= new JLabel ("Desviacion media", JLabel.CENTER);
		etiquetaVarianza				= new JLabel ("Varianza", JLabel.CENTER);
		etiquetaDesviacionTipica		= new JLabel ("Desviacion tipica", JLabel.CENTER);
		etiquetaCoeficienteCorrelacion	= new JLabel ("Coeficiente de Correlacion", JLabel.CENTER);
		
		modaX					= new JLabel ("rx1",  JLabel.CENTER);		
		medianaX				= new JLabel ("rx2",  JLabel.CENTER);		
		mediaX					= new JLabel ("",  JLabel.CENTER);		
		desviacionMediaX		= new JLabel ("rx4",  JLabel.CENTER);		
		varianzaX				= new JLabel ("rx5",  JLabel.CENTER);		
		desviacionTipicaX		= new JLabel ("rx6",  JLabel.CENTER);		
		coeficienteCorrelacionX	= new JLabel ("rx7",  JLabel.CENTER);		
		
		
		
		modaY					= new JLabel ("ry1",  JLabel.CENTER);		
		medianaY					= new JLabel ("ry2",  JLabel.CENTER);		
		mediaY 					= new JLabel ("ry3",  JLabel.CENTER);		
		desviacionMediaY			= new JLabel ("ry4",  JLabel.CENTER);		
		varianzaY				= new JLabel ("ry5",  JLabel.CENTER);		
		desviacionTipicaY		= new JLabel ("ry6",  JLabel.CENTER);		
		coeficienteCorrelacionY	= new JLabel ("ry7",  JLabel.CENTER);		
		
		
		
		add(etiquetaModa);
		add(modaX);
		add(modaY);
		
		add(etiquetaMediana);
		add(medianaX);
		add(medianaY);
		
		add(etiquetaMedia);
		add(mediaX);
		add(mediaY);
		
		add(etiquetaDesviacionMedia);
		add(desviacionMediaX);
		add(desviacionMediaY);
		
		add(etiquetaVarianza);
		add(varianzaX);
		add(varianzaY);
		
		add(etiquetaDesviacionTipica);
		add(desviacionTipicaX);
		add(desviacionTipicaY);
		
		add(etiquetaCoeficienteCorrelacion);
		add(coeficienteCorrelacionX);
		add(coeficienteCorrelacionY);
		
		setVisible(true);

	}
}
