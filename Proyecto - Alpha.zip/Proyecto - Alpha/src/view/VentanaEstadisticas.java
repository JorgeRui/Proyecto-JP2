package view;

import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;


public class VentanaEstadisticas extends JInternalFrame
{
	
	private static final long serialVersionUID = 1L;
	JLabel moda, mediana, media, desviacionMedia, varianza, desviacionTipica, coeficienteCorrelacion;

	public JLabel getModa()
	{
		return moda;
	}

	public JLabel getMediana()
	{
		return mediana;
	}

	public JLabel getMedia()
	{
		return media;
	}

	public JLabel getDesviacionMedia()
	{
		return desviacionMedia;
	}

	public JLabel getVarianza()
	{
		return varianza;
	}

	public JLabel getDesviacionTipica()
	{
		return desviacionTipica;
	}

	public JLabel getCoeficienteCorrelacion()
	{
		return coeficienteCorrelacion;
	}


	public VentanaEstadisticas() {
		super("Estadisticas", true, true, true, true);
	   
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException error) 
		{
			System.err.println("Error en clase VentanaPrincipal - Constructor");
		}
		setSize(800,300);
		setBounds(20, 100 , 440, 460);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		crearVentana();
	}
	
	public void crearVentana()
	{
		JLabel etiquetaModa, etiquetaMediana, etiquetaMedia, etiquetaDesviacionMedia, etiquetaVarianza, etiquetaDesviacionTipica, etiquetaCoeficienteCorrelacion;
	
		GridLayout gl;
		gl = new GridLayout(7,2);
		setLayout(gl);
		
		etiquetaModa					= new JLabel ("Moda", JLabel.CENTER);
		etiquetaMediana					= new JLabel ("Mediana", JLabel.CENTER);
		etiquetaMedia					= new JLabel ("Media", JLabel.CENTER);
		etiquetaDesviacionMedia			= new JLabel ("Desviacion media", JLabel.CENTER);
		etiquetaVarianza				= new JLabel ("Varianza", JLabel.CENTER);
		etiquetaDesviacionTipica		= new JLabel ("Desviacion tipica", JLabel.CENTER);
		etiquetaCoeficienteCorrelacion	= new JLabel ("Coeficiente de Correlacion", JLabel.CENTER);
		
		moda					= new JLabel ("r1",  JLabel.CENTER);		
		mediana					= new JLabel ("r2",  JLabel.CENTER);		
		media					= new JLabel ("r3",  JLabel.CENTER);		
		desviacionMedia			= new JLabel ("r4",  JLabel.CENTER);		
		varianza				= new JLabel ("r5",  JLabel.CENTER);		
		desviacionTipica		= new JLabel ("r6",  JLabel.CENTER);		
		coeficienteCorrelacion	= new JLabel ("r7",  JLabel.CENTER);		
		
		add(etiquetaModa);
		add(moda);

		add(etiquetaMediana);
		add(mediana);

		add(etiquetaMedia);
		add(media);

		add(etiquetaDesviacionMedia);
		add(desviacionMedia);

		add(etiquetaVarianza);
		add(varianza);

		add(etiquetaDesviacionTipica);
		add(desviacionTipica);

		add(etiquetaCoeficienteCorrelacion);
		add(coeficienteCorrelacion);

		
		setVisible(true);

	}
}
