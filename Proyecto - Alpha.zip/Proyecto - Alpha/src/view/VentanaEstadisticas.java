package view;

import java.awt.GridLayout;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * Clase que muestra la ventana estadisticas
 * @author Jorge Da Silva
 * @author Jennyfer
 * @author Pilar
 * 
 * @version 10.0
 */
public class VentanaEstadisticas extends JInternalFrame
{
	
	private static final long serialVersionUID = 1L;
	
	JLabel  mediaX, desviacionMediaX, varianzaX, desviacionTipicaX, coeficienteCorrelacion, mediaY, desviacionMediaY, varianzaY, desviacionTipicaY;

	/**
	 * Método que permite acceder a la media de x
	 * @return MediaX
	 */
	
	public JLabel getMediaX()
	{
		return mediaX;
	}
	
	/**
	 * Método que permite acceder a la desviacion media de x
	 * @return DesviacionMediaX
	 */
	
	public JLabel getDesviacionMediaX()
	{
		return desviacionMediaX;
	}
	/**
	 * Método que permite acceder a la varianza de x
	 * @return VarianzaX
	 */
	public JLabel getVarianzaX()
	{
		return varianzaX;
	}
	
	/**
	 *  Método que permite acceder a la desviacion tipica de x
	 * @return DesviacionTipicaX
	 */
	
	public JLabel getDesviacionTipicaX()
	{
		return desviacionTipicaX;
	}
	
	/**
	 * Método que permite acceder al coeficiente de correlacion
	 * @return CoeficienteCorrelacion
	 */
	
	public JLabel getCoeficienteCorrelacion()
	{
		return coeficienteCorrelacion;
	}
	
	
	/**
	 * Método que permite acceder a la media de y
	 * @return MediaY
	 */
	


	public JLabel getMediaY(){
		return mediaY;
	}
	/**
	 * Metodo que permite acceder a la desviacion media de y
	 * @return DesviacionMediaY
	 */
	public JLabel getDesviacionMediaY(){
		return desviacionMediaY;
	}
	/**
	 * Metodo que permite acceder a la varianza de y
	 * @return VarianzaY
	 */
	public JLabel getVarianzaY(){
		return varianzaY;
	}
	/**
	 * Metodo que permite acceder a la desviacion tipica de Y
	 * @return DesviacionTipicaY
	 */
	public JLabel getDesviacionTipicaY(){
		return desviacionTipicaY;
	}

	
	/**
	 * Creamos la vista, asignando su tamaño y posicion 
	 */
	
	
	public VentanaEstadisticas() {
		super("Estadisticas", true, true, true, true);
	   
		try{
			
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
			
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException error) 
		{
			System.err.println("Error en clase VentanaPrincipal - Constructor");
		}
		setSize(800,350);
		setBounds(20, 100 , 440, 460);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		crearVentana();
	}
	
	/**
	 * Construye la ventana con sus elementos
	 */

	public void crearVentana(){
		JLabel etiquetaMedia, etiquetaDesviacionMedia, etiquetaVarianza, etiquetaDesviacionTipica, etiquetaCoeficienteCorrelacion;
	
		GridLayout gl;
		gl = new GridLayout(5,3);
		setLayout(gl);
		

		etiquetaMedia					= new JLabel ("Media", JLabel.CENTER);
		etiquetaDesviacionMedia			= new JLabel ("Desviacion media", JLabel.CENTER);
		etiquetaVarianza				= new JLabel ("Varianza", JLabel.CENTER);
		etiquetaDesviacionTipica		= new JLabel ("Desviacion tipica", JLabel.CENTER);
		etiquetaCoeficienteCorrelacion	= new JLabel ("Coeficiente de Correlacion", JLabel.CENTER);
		

		mediaX					= new JLabel ("",  JLabel.CENTER);		
		desviacionMediaX		= new JLabel ("rx4",  JLabel.CENTER);		
		varianzaX				= new JLabel ("rx5",  JLabel.CENTER);		
		desviacionTipicaX		= new JLabel ("rx6",  JLabel.CENTER);		
		coeficienteCorrelacion	= new JLabel ("rx7",  JLabel.CENTER);		
		
			
		mediaY 					= new JLabel ("ry3",  JLabel.CENTER);		
		desviacionMediaY		= new JLabel ("ry4",  JLabel.CENTER);		
		varianzaY				= new JLabel ("ry5",  JLabel.CENTER);		
		desviacionTipicaY		= new JLabel ("ry6",  JLabel.CENTER);		
		
		
		
		add(etiquetaMedia);
		add(mediaX);
		add(mediaY);
		
		add(etiquetaDesviacionMedia);
		add(desviacionMediaX);
		add(desviacionMediaY);
		
		add(etiquetaVarianza);
		add(varianzaX);
		add(varianzaY);
		
		add(etiquetaDesviacionTipica);
		add(desviacionTipicaX);
		add(desviacionTipicaY);
		
		add(etiquetaCoeficienteCorrelacion);
		add(coeficienteCorrelacion);
		
		setVisible(true);

	}
}
