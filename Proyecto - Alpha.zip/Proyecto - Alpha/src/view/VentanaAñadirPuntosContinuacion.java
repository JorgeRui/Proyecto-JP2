package view;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import control.ControladorGuardarPuntos;

public class VentanaAñadirPuntosContinuacion extends JInternalFrame
{
	private static final long serialVersionUID = 1L;
	public JTextField[] puntosTF;
	JLabel[] etiquetasPuntos;
	JButton crearArchivo;
	JLabel titulo1, titulo2;
	ControladorGuardarPuntos cgp;
	public VentanaAñadirPuntosContinuacion(int numeroPuntos) 
	{
		super("Añadir Puntos", true, true, true, true);
		
		etiquetasPuntos = new JLabel[numeroPuntos];
		puntosTF		= new JTextField[numeroPuntos];
		crearArchivo	= new JButton("Crear archivo");
		this.setSize(800,300);
		this.setBounds(20, 100 , 650, 460);
		this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	}
	
	public void crearVentana() {
		setLayout(new BorderLayout());
		JPanel panelCentral = new JPanel();
		JPanel panelArriba  = new JPanel();
		panelCentral.setLayout(new GridLayout(etiquetasPuntos.length, 2));
		panelArriba.setLayout(new GridLayout(1,3));
		
		for (int i = 0; i < etiquetasPuntos.length; i++)
		{
			etiquetasPuntos[i] = new JLabel();
			etiquetasPuntos[i].setText("Punto número: " + (i + 1));
			panelCentral.add(etiquetasPuntos[i]);
			
			puntosTF[i] = new JTextField(3);
			panelCentral.add(puntosTF[i]);
			

		}
		
		titulo1 = new JLabel("Punto:", JLabel.CENTER);
		titulo1.setFont(new Font("Impact",Font.ITALIC, 12));
		
		titulo2 = new JLabel("Valor X; ValorY", JLabel.CENTER);
		titulo2.setFont(new Font("Impact",Font.ITALIC, 12));



		panelArriba.add(titulo1);
		panelArriba.add(titulo2);

		add(panelCentral, BorderLayout.CENTER);
		add(crearArchivo, BorderLayout.SOUTH);
		add(panelArriba, BorderLayout.NORTH);
		setVisible(true);
	}
	public void asignarControlador(ControladorGuardarPuntos cgp)
	{
		this.cgp = cgp;
	}
	public void añadirListeners()
	{
		crearArchivo.addActionListener(cgp);
	}
}
