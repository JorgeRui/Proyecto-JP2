package view;

import javax.swing.JDesktopPane;
import javax.swing.JFrame;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import control.ControladorPrincipal;

public class VentanaPrincipal extends JFrame
{
	
	private static final long serialVersionUID = 1L;
	
	public static final String MOSTRARGRAFICA	= "MOSTRARGRAFICA";
	public static final String ANADIRARCHIVOAC	= "ANAC";
	public static final String ANADIRPUNTOSAC	= "ANADIRPUNTOSAC";
	public static final String MOSTRARPUNTOSAC	= "MOSTRARPUNTOSAC";
	public static final String MOSTRARLOGAC		= "MOSTRARLOGAC";
	public static final String MOSTRARAYUDAAC 	= "MOSTRARAYUDAAC";
	
	ControladorPrincipal cpi;
	VentanaGrafica ventanaGrafica;

	JMenuBar 	menuBar;
	JMenu   	menuGrafica, menuAbrir, menuPuntos, menuAyuda;
	JMenuItem 	menuMostrarGrafica, menuItemAbrir, menuPuntoMostrar, menuPuntoAnadir, menuMostrarLog, menuMostrarAyuda;
	
	public JMenuItem getMenuItemAbrir()
	{
		return menuItemAbrir;
	}
	
	public VentanaGrafica getVentanaGrafica()
	{
		return ventanaGrafica;
	}

	public VentanaPrincipal(ControladorPrincipal cpi)
	{
		super("Proyecto - ALPHA");
		this.cpi = cpi;
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException error) 
		{
			System.err.println("Error en clase VentanaPrincipal - Constructor");
		}
		
		setSize(1800,1020);
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		setContentPane(new JDesktopPane());
		crearMenu();
		anadirListeners();
		System.out.println("Listeners de VentanaPrincipal asignados");

	}
	
	public void crearMenu()
	{	
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		menuGrafica = new JMenu("Grafica");
		menuAbrir 	= new JMenu("Abrir Fichero");
		menuAyuda	= new JMenu("Ayuda");
		menuPuntos	= new JMenu("Puntos");
		
		menuMostrarGrafica	= new JMenuItem("Mostrar Grafica");
		menuItemAbrir		= new JMenuItem("Abrir...");
		menuPuntoMostrar 	= new JMenuItem("Mostrar");
		menuPuntoAnadir 	= new JMenuItem("Añadir");
		menuMostrarLog 		= new JMenuItem("Mostrar Log");
		menuMostrarAyuda 	= new JMenuItem("Mostrar Ayuda");
		
		menuGrafica.add(menuMostrarGrafica);
		menuAbrir.add(menuItemAbrir);
		menuPuntos.add(menuPuntoMostrar);
		menuPuntos.add(menuPuntoAnadir);
		menuAyuda.add(menuMostrarLog);
		menuAyuda.add(menuMostrarAyuda);
		
		menuBar.add(menuGrafica);
		menuBar.add(menuAbrir);
		menuBar.add(menuPuntos);
		menuBar.add(menuAyuda);
				
	}
	
	
	public void anadirListeners()
	{
		menuMostrarGrafica.setActionCommand(MOSTRARGRAFICA);
		menuItemAbrir.setActionCommand(ANADIRARCHIVOAC);
		menuPuntoAnadir.setActionCommand(ANADIRPUNTOSAC);
		menuPuntoMostrar.setActionCommand(MOSTRARPUNTOSAC);
		menuMostrarLog.setActionCommand(MOSTRARLOGAC);
		menuMostrarAyuda.setActionCommand(MOSTRARAYUDAAC);
		
		menuMostrarGrafica.addActionListener(cpi);
		menuItemAbrir.addActionListener(cpi);
		menuPuntoAnadir.addActionListener(cpi);
		menuMostrarLog.addActionListener(cpi);
		menuPuntoMostrar.addActionListener(cpi);
		menuMostrarAyuda.addActionListener(cpi);
	}
	public void añadirVentanaGrafica(VentanaGrafica ventanaGrafica)
	{
		this.ventanaGrafica = ventanaGrafica;
		add(ventanaGrafica);
	}

}
