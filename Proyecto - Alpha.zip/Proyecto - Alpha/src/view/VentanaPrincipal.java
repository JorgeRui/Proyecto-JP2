package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSlider;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import control.ControladorPrincipal;


public class VentanaPrincipal extends JFrame
{

	
	// -------------- VARIABLES DEL PROGRAMA --------------
	private static final long serialVersionUID = 1L;
	public static final String BOTONESTADISTICAAC = "BEAC";
	public static final String BOTONCAMBIARAC = "BCAC";
	public static final String BOTONMOSTRARESTADISTICAAC = "BMEAC";

	ControladorPrincipal cpi;
	JMenuBar 	menuBar;
	JMenu   	menuAbrir, menuPuntos, menuAyuda;
	JMenuItem 	menuItemAbrir, menuPuntoMostrar, menuPuntoAnadir;
	
	JPanel		panelDerecho;
	JCheckBox	mostrarValor, mostrarEjes, lineaRegresion;
	JButton 	botonEstadistica, botonCambiar, botonMostrarEstadistica;
	JSlider 	slider;
	JLabel		labelSlider, labelInfoUsuario;
	PaintPanel	paintPanel;
	public VentanaPrincipal(ControladorPrincipal cpi)
	{
		super("Proyecto - ALPHA");
		this.cpi = cpi;
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException error) 
		{
			System.err.println("Error en clase VentanaPrincipal - Constructor");
		}
		setSize(1800,1020);
		setLayout(new BorderLayout());
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);

		crearMenu();
		paintPanel 		 = new PaintPanel();
		labelInfoUsuario = new JLabel("Informaci�n de utilidad para el usuario");
		
		labelInfoUsuario.setFont(new Font("Courier", Font.ITALIC, 30));
		labelInfoUsuario.setBackground(Color.DARK_GRAY);
		//TODO: Cambiar el color del texto en funci�n de la utilidad, es decir, a��dir variable
		labelInfoUsuario.setForeground(Color.GRAY);
		
		paintPanel.setBackground(Color.WHITE);
	
		add(paintPanel, BorderLayout.CENTER);	
		add(crearDerecha(), BorderLayout.EAST);
		add(labelInfoUsuario, BorderLayout.SOUTH);
	}

	public void crearMenu()
	{	
		menuBar = new JMenuBar();
		setJMenuBar(menuBar);
		
		menuAbrir 	= new JMenu("Abrir Fichero");
		menuAyuda	= new JMenu("Ayuda");
		menuPuntos	= new JMenu("Puntos");
		//menuItemAbrir.addActionListener(new MenuListener(menuItemAbrir));
		menuItemAbrir		= new JMenuItem("Abrir...");
		menuPuntoMostrar 	= new JMenuItem("Mostrar");
		menuPuntoAnadir 	= new JMenuItem("Añadir");
		
		menuAbrir.add(menuItemAbrir);
		menuPuntos.add(menuPuntoMostrar);
		menuPuntos.add(menuPuntoAnadir);
		
		menuBar.add(menuAbrir);
		menuBar.add(menuPuntos);
		menuBar.add(menuAyuda);
	}
	
	public JComponent crearDerecha()
	{
		// ---- INICIALIZADORES ----
		panelDerecho 	 		= new JPanel();
		botonEstadistica		= new JButton("Calcular estadistica");
		botonCambiar 	 		= new JButton("Cambiar");
		botonMostrarEstadistica = new JButton("Mostrar estadistica");
		slider			 		= new JSlider(JSlider.HORIZONTAL, 0, 30,15);
		labelSlider		 		= new JLabel("Ejes");
		mostrarEjes 	 		= new JCheckBox("Mostrar ejes");
		lineaRegresion 	 		= new JCheckBox("Mostrar linea de regresion");
		mostrarValor 	 		= new JCheckBox("Mostrar valor");

		// ---- PANEL DERECHO ----
		panelDerecho.setLayout(new GridLayout(3,3));
		// ---- BOTONES ----
		botonEstadistica.setToolTipText("bla bla1");
		botonCambiar.setToolTipText("bla bla2");
		botonMostrarEstadistica.setToolTipText("bla bla6");
		// ---- SLIDER Y ETIQUETA ----
		labelSlider.setOpaque(true);
		slider.setMajorTickSpacing(10);
		slider.setMinorTickSpacing(1);
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		slider.setToolTipText("bla bla2");
		// ---- JCHECKBOX ----
		mostrarEjes.setToolTipText("bla bla3");
		lineaRegresion.setToolTipText("bla bla4");
		mostrarValor.setToolTipText("bla bla5");
		// ---- A�ADIMOS AHORA AL JPANEL ----
		panelDerecho.add(botonEstadistica);
		panelDerecho.add(botonCambiar);
		panelDerecho.add(botonMostrarEstadistica);
		panelDerecho.add(labelSlider);
		panelDerecho.add(slider);
		panelDerecho.add(mostrarEjes);
		panelDerecho.add(lineaRegresion);
		panelDerecho.add(mostrarValor);
		
		return panelDerecho;
	}
	/**
	 * M�TODO QUE SE ENCARGA DE A�ADIR LOS DIFERENTES LISTENERS A LOS COMPONENTES
	 */
	public void a�adirListeners()
	{
		botonEstadistica.addActionListener(cpi);
		botonCambiar.addActionListener(cpi);
		botonMostrarEstadistica.addActionListener(cpi);
		
		botonEstadistica.setActionCommand(BOTONESTADISTICAAC);
		botonCambiar.setActionCommand(BOTONCAMBIARAC);
		botonMostrarEstadistica.setActionCommand(BOTONMOSTRARESTADISTICAAC);
		
		mostrarEjes.addChangeListener(cpi);
	}
	
}
