package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Dimension;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JComponent;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;

import control.ControladorGrafica;


public class VentanaGrafica extends JInternalFrame {

	// -------------- VARIABLES DEL PROGRAMA --------------
	private static final long serialVersionUID = 1L;
	public static final String BOTONGUARDARIMAGENAC = "BOTONGUARDARIMAGENAC";
	public static final String BOTONCAMBIARCOLORAC = "BOTONCAMBIARCOLORAC";
	public static final String BOTONMOSTRARESTADISTICAAC = "BOTONMOSTRARESTADISTICAAC";
	public static final String MOSTRAREJESAC = "MOSTRAREJESAC";
	public static final String LINEAREGRESIONAC = "LINEAREGRESIONAC";
	public static final String BOTONLINEAREGRESIONAC = "BOTONLINEAREGRESIONAC";

	ControladorGrafica cpg;

	
	JPanel		panelDerecho, panelArribaDerecha, panelAbajoDerecha, panelCentralDerecha;
	JButton 	botonGuardarImagen, botonCambiarColor, botonMostrarEstadistica, botonLineaRegresion;
;	
	JLabel		labelInfoUsuario;
	PaintPanel	paintPanel;
	public JCheckBox	mostrarValor, mostrarEjes, lineaRegresion;
	
	public PaintPanel getPaintPanel() {
		return paintPanel;
	}



	public VentanaGrafica(ControladorGrafica cpg)
	{
		super("Ventana Grafica", false, true, false, true);
		this.cpg = cpg;

		this.setSize(1178,1070);
		setLayout(new BorderLayout());
		setDefaultCloseOperation(JInternalFrame.HIDE_ON_CLOSE);

		paintPanel 		 = new PaintPanel();
		labelInfoUsuario = new JLabel("Informacion de utilidad para el usuario");
		
		labelInfoUsuario.setFont(new Font("Courier", Font.ITALIC, 30));
		labelInfoUsuario.setBackground(Color.DARK_GRAY);
		labelInfoUsuario.setForeground(Color.GRAY);
		
		paintPanel.setBackground(Color.WHITE);
		paintPanel.setPreferredSize(new Dimension(1000,1000));
		add(paintPanel, BorderLayout.CENTER);	
		add(crearDerecha(), BorderLayout.EAST);
		add(labelInfoUsuario, BorderLayout.SOUTH);
		
		anadirListeners();
		System.out.println("Listeners asignados");
		this.setVisible(true);

	}


	
	public JComponent crearDerecha() {
		// ---- INICIALIZADORES ----
		panelDerecho 	 		= new JPanel();
		panelArribaDerecha		= new JPanel();
		panelAbajoDerecha		= new JPanel();
		panelCentralDerecha		= new JPanel();
		
		panelArribaDerecha.setLayout(new GridLayout(3,1));
		panelCentralDerecha.setLayout(new GridLayout(3,1));
		panelAbajoDerecha.setLayout(new GridLayout(3,1));
		
		botonGuardarImagen		= new JButton("Guardar Imagen");
		botonCambiarColor 	 	= new JButton("Cambiar color");
		botonMostrarEstadistica = new JButton("Mostrar estadistica");
		botonLineaRegresion 	= new JButton ("Linea de regresion");

		mostrarEjes 	 		= new JCheckBox("Mostrar ejes");
		lineaRegresion 	 		= new JCheckBox("Mostrar linea de regresion");
		mostrarValor 	 		= new JCheckBox("Mostrar valor");

		// ---- PANEL DERECHO ----
		panelDerecho.setLayout(new BorderLayout());
		// ---- BOTONES ----
		botonGuardarImagen.setToolTipText("bla bla1");
		botonCambiarColor.setToolTipText("bla bla2");
		botonMostrarEstadistica.setToolTipText("bla bla6");

		// ---- JCHECKBOX ----
		mostrarEjes.setToolTipText("bla bla3");
		lineaRegresion.setToolTipText("bla bla4");
		mostrarValor.setToolTipText("bla bla5");
		// ---- ANADIMOS AHORA AL JPANEL ----
		panelArribaDerecha.add(botonGuardarImagen);
		panelArribaDerecha.add(botonCambiarColor);
		panelArribaDerecha.add(botonMostrarEstadistica);
		panelArribaDerecha.add(botonLineaRegresion);

		
		
		panelAbajoDerecha.add(mostrarEjes);
		panelAbajoDerecha.add(lineaRegresion);
		panelAbajoDerecha.add(mostrarValor);
		
		panelDerecho.add(panelArribaDerecha, BorderLayout.NORTH);
		panelDerecho.add(panelCentralDerecha, BorderLayout.CENTER);
		panelDerecho.add(panelAbajoDerecha, BorderLayout.SOUTH);
		return panelDerecho;
	}
	/**
	 * METODO QUE SE ENCARGA DE ANADIR LOS DIFERENTES LISTENERS A LOS COMPONENTES
	 */
	public void anadirListeners() {
		botonGuardarImagen.addActionListener(cpg);
		botonCambiarColor.addActionListener(cpg);
		botonMostrarEstadistica.addActionListener(cpg);
		botonLineaRegresion.addActionListener(cpg);
	
		
		mostrarEjes.addItemListener(cpg);
		lineaRegresion.addItemListener(cpg);
		mostrarValor.addItemListener(cpg);
		
		mostrarEjes.setActionCommand("MOSTRAREJESAC");
		lineaRegresion.setActionCommand("LINEAREGRESIONAC");

		botonGuardarImagen.setActionCommand(BOTONGUARDARIMAGENAC);
		botonCambiarColor.setActionCommand(BOTONCAMBIARCOLORAC);
		botonMostrarEstadistica.setActionCommand(BOTONMOSTRARESTADISTICAAC);
		botonLineaRegresion.setActionCommand(BOTONLINEAREGRESIONAC);



	}
	public void cambiarLabelAyuda(String text, int modo)
	{
		switch (modo) 
		{
		//MODO NORMAL, INFO DE UTILIDAD
		case 1:
			labelInfoUsuario.setText(text);
			labelInfoUsuario.setForeground(Color.LIGHT_GRAY);
			//TODO: AHORA GUARDAR AQUI EN EL LOG
			break;
		//ADVERTENCIA DEL PROGRAMA
		case 2:
			labelInfoUsuario.setText(text);
			labelInfoUsuario.setForeground(Color.YELLOW);
			//TODO: AHORA GUARDAR AQUI EN EL LOG
			break;
		//ERROR FATALISIMO
		case 3:
			labelInfoUsuario.setText(text);
			labelInfoUsuario.setForeground(Color.RED);
			//TODO: AHORA GUARDAR AQUI EN EL LOG
			break;
		default:
			System.err.println("Error, comando no reconocido");
			break;
		}
	}
}
