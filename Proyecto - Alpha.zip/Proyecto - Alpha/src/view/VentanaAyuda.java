/**
 * Extiende a JInternalFrame
 */
package view;

import javax.swing.JEditorPane;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

/**
 * Clase que contiene el manual de usuario
 * @author Jorge Da Silva
 * @author Jennyfer
 * @author Pilar
 *
 * @version 10.0
 */
public class VentanaAyuda extends JInternalFrame
{
	private static final long serialVersionUID = 1L;
	/**
	 * Crea una ventana para la ayuda del usuario
	 */
	public VentanaAyuda() {
		super("Manual de Usuario", true, true, true, true);
	   
		try{
			
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
			
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException error) 
		{
			System.err.println("Error en clase VentanaPrincipal - Constructor");
		}
		setSize(800,400);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		crearVentana();
		this.setVisible(true);
	}
	/**
	 * Introduce el texto en la ventana ayuda
	 */
	public void crearVentana()
	{
		JEditorPane texto = new JEditorPane();
		
		texto.setContentType("text/html");
		texto.setText("<p>Manual de usuario proyecto de programación   Para comenzar a graficar sus puntos, primero deberá pulsar “Abrir Fichero” opción con la que podrá elegir el fichero .txt que desee utilizar. A continuación, si quiere calcular las estadísticas de la función representada pulse “Calcular estadística” y para poder visualizarlas deberá pulsar “Mostrar estadística”.   Este programa ofrece la posibilidad de cambiar el color de los puntos, pulsando la opción “Cambiar color”.También dispone de una opción para trabajar sobre los puntos, pulsando “Puntos” puedes elegir entre mostrar o añadir tus puntos. En “Mostrar” aparecerá una tabla donde podrá ver los puntos de su archivo.  En “Añadir” podrá introducir el título, el autor, el título del eje “x”, el del eje “y”, y el número de puntos que desee introducir, a continuación cuando pulse en “ok” deberá introducir los puntos separándolos por “ ; “.  Dispone de un botón“Guardar imagen”, que al pulsarlo, hará que la gráfica de guarde como un archivo JPG.   En el margen inferior derecho de la ventana de la gráfica, hay tres checkbox, al pulsar en “Mostrar ejes” aparecerá el nombre de cada eje, al pulsar en “Mostrar línea de regresión”, aparecerá la línea de regresión correspondiente a esos puntos, y al pulsar en “en mostrar valor” , te saldrá el valor de cada punto. Para quitar cualquiera de estas opciones solo tendrá que volver a pulsar sobre estas.   Si pulsa en “Ayuda” verá que puede seleccionar “Log de usuario”, donde aparecerá una ventana con las tareas que se han realizado, este log podrá ser enviado o guardado, pulsando cada una de sus opciones. También podrá seleccionar “Mostrar ayuda”, donde dispondrá de un breve manual de usuario.   Si en algún momento cierra la pestaña donde se encuentra la gráfica, podrá visualizarla de nuevo pulsando la opción”Gráfica”.  </p>");
		
		add(texto);
	}
}
