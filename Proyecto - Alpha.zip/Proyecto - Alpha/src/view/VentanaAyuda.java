package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;

import control.Launcher;

public class VentanaAyuda extends JInternalFrame
{
	public static final String GUARDARLOGAC	= "GUARDARLOGAC";
	public static final String ENVIARLOGAC	= "ENVIARLOGAC";

	private static final long serialVersionUID = 1L;
	static DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	
	JScrollPane scrollPane;
	JButton guardarLog, enviarLog;
	static JTextArea textAreaLog;
	private Document documento;
	private DocumentListener maximoLineasLimite;


	public static JTextArea getTextAreaLog()
	{
		return textAreaLog;
	}

	public VentanaAyuda()
	{
		super("Log del usuario", true, true, true, true);

		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException error) 
		{
			System.err.println("Error en clase VentanaPrincipal - Constructor");
		}
		
		setSize(800,300);
		setBounds(20, 100 , 440, 460);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		crearVentana();
	}
	
	public void crearVentana()
	{
		setLayout(new BorderLayout());
		
		Date fecha = new Date();
		String fechaActual = dateFormat.format(fecha).toString();
		JPanel panelAbajo = new JPanel();
		panelAbajo.setLayout(new GridLayout(1,2));
		guardarLog	 = new JButton("Guardar Log");
		enviarLog	 = new JButton("Enviar Log");
		panelAbajo.add(guardarLog);
		panelAbajo.add(enviarLog);
		
		textAreaLog  = new JTextArea(fechaActual+ "\t" + "Hola buenos días");
		scrollPane	 = new JScrollPane(textAreaLog, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		añadirLog("Pruebas");
		añadirLog("Que tal todo");
		textAreaLog.setEditable(false);

		add(scrollPane, BorderLayout.CENTER);
		add(panelAbajo, BorderLayout.SOUTH);
		añadirListeners();
		setVisible(true);
	}
	public void añadirListeners()
	{
		guardarLog.addActionListener(Launcher.getCa());
		enviarLog.addActionListener(Launcher.getCa());
		
		guardarLog.setActionCommand(GUARDARLOGAC);
		enviarLog.setActionCommand(ENVIARLOGAC);
	}
	public static void añadirLog(String texto)
	{
		Date fecha = new Date();
		String fechaActual = dateFormat.format(fecha).toString();
		textAreaLog.setText(textAreaLog.getText() + "\n" + fechaActual + "\t" + texto);
	}
}
