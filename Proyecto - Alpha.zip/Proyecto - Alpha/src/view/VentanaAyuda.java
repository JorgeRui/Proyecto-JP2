package view;

import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;
import javax.swing.event.DocumentListener;
import javax.swing.text.Document;

public class VentanaAyuda extends JInternalFrame
{
	static DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	
	JScrollPane scrollPane;
	static JTextArea textAreaLog;
	private Document documento;
	private DocumentListener maximoLineasLimite;


	private static final long serialVersionUID = 1L;

	public VentanaAyuda()
	{
		super("Log del usuario", true, true, true, true);

		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException error) 
		{
			System.err.println("Error en clase VentanaPrincipal - Constructor");
		}
		
		setSize(800,300);
		setBounds(20, 100 , 440, 460);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		crearVentana();
	}
	
	public void crearVentana()
	{
		Date fecha = new Date();
		String fechaActual = dateFormat.format(fecha).toString();
		textAreaLog  = new JTextArea(fechaActual+ "\t" + "Hola buenos días");
		scrollPane	 = new JScrollPane(textAreaLog, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		añadirLog("Pruebas");
		añadirLog("Que tal todo");
		textAreaLog.setEditable(false);

		add(textAreaLog);
		setVisible(true);
	}
	public static void añadirLog(String texto)
	{
		Date fecha = new Date();
		String fechaActual = dateFormat.format(fecha).toString();
		textAreaLog.setText(textAreaLog.getText() + "\n" + fechaActual + "\t" + texto);
	}
}
