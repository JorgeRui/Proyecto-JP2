package view;

import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

public class VentanaAyuda extends JInternalFrame
{

	Vector<String> log;
	
	private static final long serialVersionUID = 1L;

	public VentanaAyuda()
	{
		super("Estadisticas", true, true, true, true);
		   
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException error) 
		{
			System.err.println("Error en clase VentanaPrincipal - Constructor");
		}
		
		setSize(800,300);
		setBounds(20, 100 , 440, 460);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
	}
	
	public void crearVentana()
	{
		//TODO FALTA AÑADIR ESTO
	}
}
