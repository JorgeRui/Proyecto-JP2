package view;

import java.awt.BorderLayout;
import java.awt.GridLayout;
import java.text.DateFormat;
import java.text.SimpleDateFormat;
import java.util.Date;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JPanel;
import javax.swing.JScrollPane;
import javax.swing.JTextArea;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import control.Launcher;

/**
 * Crea la ventana donde se guarda el 'LOG' del programa
 * @author Jorge Da Silva
 * @author Jennyfer
 * @author Pilar
 * 
 * @version 10.0
 */
public class VentanaLog extends JInternalFrame
{
	public static final String GUARDARLOGAC	= "GUARDARLOGAC";
	public static final String ENVIARLOGAC	= "ENVIARLOGAC";

	private static final long serialVersionUID = 1L;
	static DateFormat dateFormat = new SimpleDateFormat("dd/MM/yyyy HH:mm:ss");
	
	JScrollPane scrollPane;
	JButton guardarLog, enviarLog;
	static JTextArea textAreaLog;

	/**
	 * Método que permite acceder a el Area de Log
	 * @return TextAreaLog
	 */

	public static JTextArea getTextAreaLog()
	{
		return textAreaLog;
	}
	
	/**
	 * Creamos la vista, asignando su tamaño y su posicion 
	 */
	
	public VentanaLog()
	{
		super("Log del usuario", true, true, true, true);

		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException error) 
		{
			System.err.println("Error en clase VentanaPrincipal - Constructor");
		}
		
		setSize(800,300);
		setBounds(20, 100 , 440, 460);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		crearVentana();
	}
	
	/**
	 * Construye la ventana con sus elementos
	 */
	
	public void crearVentana()
	{
		setLayout(new BorderLayout());
		
		Date fecha = new Date();
		String fechaActual = dateFormat.format(fecha).toString();
		JPanel panelAbajo = new JPanel();
		panelAbajo.setLayout(new GridLayout(1,2));
		guardarLog	 = new JButton("Guardar Log");
		enviarLog	 = new JButton("Enviar Log");
		panelAbajo.add(guardarLog);
		panelAbajo.add(enviarLog);
		
		textAreaLog  = new JTextArea(fechaActual + "\t" + "Esto es una ventana que registra los eventos que van ocurriendo");
		añadirLog("Programa iniciado");
		scrollPane	 = new JScrollPane(textAreaLog, JScrollPane.VERTICAL_SCROLLBAR_AS_NEEDED, JScrollPane.HORIZONTAL_SCROLLBAR_AS_NEEDED);
		textAreaLog.setEditable(false);

		add(scrollPane, BorderLayout.CENTER);
		add(panelAbajo, BorderLayout.SOUTH);
		añadirListeners();
	}
	

	/**
	 * 
	 * Añadimos los listeners a los elementos
	 */
	
	
	public void añadirListeners()
	{
		guardarLog.addActionListener(Launcher.getCa());
		enviarLog.addActionListener(Launcher.getCa());
		
		guardarLog.setActionCommand(GUARDARLOGAC);
		enviarLog.setActionCommand(ENVIARLOGAC);
	}
	
	/**
	 * Genera un string que añade a el {@code JTextArea} 
	 * @param texto
	 */
	
	
	public void añadirLog(String texto)
	{
		Date fecha = new Date();
		String fechaActual = dateFormat.format(fecha).toString();
		textAreaLog.setText(textAreaLog.getText() + "\n" + fechaActual + "\t" + texto);
	}
}
