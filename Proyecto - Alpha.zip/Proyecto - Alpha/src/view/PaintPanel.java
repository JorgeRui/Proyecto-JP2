package view;


import java.awt.Color;

import java.awt.Graphics;
import java.util.Vector;

import javax.swing.JPanel;

import control.Launcher;
import model.Punto;

public class PaintPanel extends JPanel
{

	private static final long serialVersionUID = 4175391112773546138L;

	
	int[] x, y;
	Vector<Punto> puntos;
	Color colorGrafica;
	String ejeX = "Eje X", ejeY = "Eje Y";
	boolean mostrarValor, mostrarEjes, mostrarLineaRegresion;

	public void setEjeX(String ejeX)
	{
		this.ejeX = ejeX;
	}
	public void setEjeY(String ejeY)
	{
		this.ejeY = ejeY;
	}
	public Vector<Punto> getPuntos()
	{
		return puntos;
	}
	public void setPuntos(Vector<Punto> puntos) 
	{
		this.puntos = puntos;
	}
	
	public Color getColorGrafica() 
	{
		return colorGrafica;
	}
	public void setColorGrafica(Color colorGrafica) 
	{
		this.colorGrafica = colorGrafica;
	}
	
	public void setMostrarValor(boolean mostrarValor)
	{
		this.mostrarValor = mostrarValor;
	}
	public void setMostrarEjes(boolean mostrarEjes)
	{
		this.mostrarEjes = mostrarEjes;
	}
	public void setMostrarLineaRegresion(boolean mostrarLineaRegresion)
	{
		this.mostrarLineaRegresion = mostrarLineaRegresion;
	}
	@Override
	protected void paintComponent(Graphics g) 
	{
		super.paintComponent(g);
		int xsub2 = this.getWidth()/2;
		int ysub2 = this.getHeight()/2;
		g.setColor(Color.BLACK);
		g.drawLine(0, this.getHeight()/2, this.getWidth(), this.getHeight()/2);
		g.drawLine(this.getWidth()/2, 0,this.getWidth()/2 , this.getHeight());
		
		for (int i = 0; i < 5000; i+=10) 
		{
			g.setColor(Color.RED);
			g.drawLine(i, ysub2 - 2 , i, ysub2 + 2 );
			g.drawLine(xsub2 - 2, i, xsub2 + 2, i);
		}
		try 
		{
			if (puntos != null) 
			{

				Launcher.getVentanaG().cambiarLabelAyuda("Dibujando puntos", 1);
				Launcher.getVentanaLog().añadirLog("Puntos dibujados");
				dibujarFuncion(puntos, g);
			}
			if (mostrarValor == true && puntos != null)
			{
				dibujarValores(puntos, g, x, y);
			}
			
		} catch (Exception error) 
		{
			Launcher.getVentanaG().cambiarLabelAyuda("Error en paint panel", 3);
			Launcher.getVentanaLog().añadirLog("Error en el paint panel");
			System.err.println("Error en paint panel");
			System.err.println(error.getCause());
		}
		if (mostrarEjes == true)
		{
			dibujarEjes(g);
		}
	}
	public void dibujarGrid(Graphics g)
	{
		
	}
	
	
//	public void dibujarEjes(String ejeX, String ejeY, Graphics g)
//	{
//		this.ejeY = ejeY;
//		this.ejeX = ejeX;
//		g.drawString(ejeY, (this.getWidth() / 2) + 10, 30);
//		g.drawString(ejeX, this.getWidth() - 80, this.getHeight() / 2 + 30);
//	}
	
	
	/**
	 * Metodo que dibuja una función a partir de un número de puntos dados
	 * @param puntos el vector con los puntos
	 * @param g el grafico dónde va a dibujar
	 */
	public void dibujarFuncion(Vector<Punto> puntos, Graphics g)
	{
		x = new int[puntos.size()];
		y = new int[puntos.size()];
		
		try 
		{
			for (int i = 0; i < puntos.size(); i++) 
			{
				x[i] = (int) puntos.get(i).getX();
				y[i] = (int) puntos.get(i).getY();
			}
			if (x == null || y == null) 
			{
				Launcher.getVentanaG().cambiarLabelAyuda("Error en paint panel", 3);
				Launcher.getVentanaLog().añadirLog("Error en el paint panel");
				System.err.println("X e Y son NULL! - Error en dibujar funcion");
			}
			for (int i = 0; i < puntos.size()-1; i++)
			{
				g.setColor(colorGrafica);
				g.fillOval(x[i], y[i], 7, 7);

			}		
			
		} catch (Exception error) 
		{
			Launcher.getVentanaG().cambiarLabelAyuda("Error en paint panel", 3);
			System.err.println("ERROR EN CLASE PAINT PANEL - DIBUJAR FUNCION");
			error.getMessage();
		}
	
	}
	public void dibujarValores(Vector<Punto> puntos, Graphics g, int[] x, int[] y)
	{
		for (int i = 0; i < puntos.size(); i++)
		{
			g.setColor(Color.GRAY);
			g.drawString(Launcher.getCpi().getPuntos().get(i).toString(), x[i], y[i] - 3);
		}
	}
	public void dibujarEjes(Graphics g)
	{
		int xsub2 = this.getWidth()/2;
		int ysub2 = this.getHeight()/2;
		g.setColor(Color.ORANGE);

		System.out.println(ejeY);
		System.out.println(ejeX);
		
		g.drawString(ejeY, xsub2 + 10, 30);
		g.drawString(ejeX, this.getWidth() - 80, ysub2 + 30);
		g.setColor(Color.BLACK);

	}
}