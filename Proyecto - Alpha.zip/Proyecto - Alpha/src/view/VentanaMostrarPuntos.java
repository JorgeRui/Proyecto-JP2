package view;

import java.util.Vector;

import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JScrollPane;
import javax.swing.JTable;
import javax.swing.UIManager;
import javax.swing.UnsupportedLookAndFeelException;

import model.Punto;

public class VentanaMostrarPuntos extends JInternalFrame
{
	private static final long serialVersionUID = 1L;
	Vector<Punto> puntos;
	
	public Vector<Punto> getPuntos() 
	{
		return puntos;
	}

	public void setPuntos(Vector<Punto> puntos) 
	{
		this.puntos = puntos;
	}

	JTable tabla;
	JScrollPane scrollPane;
	public VentanaMostrarPuntos()
	{
		super("Puntos", true, true, true, true);
		   
		try
		{
			UIManager.setLookAndFeel("com.sun.java.swing.plaf.nimbus.NimbusLookAndFeel");
		} catch (ClassNotFoundException | InstantiationException | IllegalAccessException | UnsupportedLookAndFeelException error) 
		{
			System.err.println("Error en clase VentanaPrincipal - Constructor");
		}
		setSize(600,300);
		setBounds(20, 100 , 440, 460);
		setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		this.setVisible(true);
	}
	
	public void crearVentana()
	{
		Object[][] valores = new Object[puntos.size()][3];
		//crea una matriz con todos los valores de los puntos
		for (int i = 0; i < puntos.size(); i++) 
		{
			valores[i][0] = (i+1);
			valores[i][1] = puntos.get(i).getX();
			valores[i][2] = puntos.get(i).getY();
			
		}
		// crea un array con el nombre de las columnas que aparecerá en la tabla
		String[] cabecera = {"Número", "Valor X", "Valor Y"};
		//crea la tabla
		tabla = new JTable(valores,cabecera);
		
		//desactiva ediccion de la tabla
		tabla.setEnabled(false);		
		scrollPane = new JScrollPane(tabla);
		add(scrollPane);
		System.out.println("Creada ventana");
		this.setVisible(true);
	}
}
