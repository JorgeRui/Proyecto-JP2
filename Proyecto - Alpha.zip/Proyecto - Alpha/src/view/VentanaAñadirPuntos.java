package view;

import java.awt.BorderLayout;
import java.awt.Font;
import java.awt.GridLayout;

import javax.swing.JButton;
import javax.swing.JFrame;
import javax.swing.JInternalFrame;
import javax.swing.JLabel;
import javax.swing.JPanel;
import javax.swing.JTextField;

import control.Launcher;

public class VentanaAñadirPuntos extends JInternalFrame
{
	public static final String OK = "OK";
	public static final String CANCELAR = "CANCELAR";

	private static final long serialVersionUID = 1L;

	
	JPanel panelCentral, panelAbajo;
	JLabel titulo, autor, numeroPuntos, cabecera, ejeX, ejeY;
	JTextField tituloTF, autorTF, numeroPuntosTF, ejeXTF, ejeYTF;

	JButton ok, cancelar;
	
	public JLabel getAutor()
	{
		return autor;
	}

	public JLabel getNumeroPuntos()
	{
		return numeroPuntos;
	}

	public JTextField getTituloTF()
	{
		return tituloTF;
	}

	public JTextField getAutorTF()
	{
		return autorTF;
	}

	public JTextField getNumeroPuntosTF()
	{
		return numeroPuntosTF;
	}
	public JTextField getEjeXTF()
	{
		return ejeXTF;
	}

	public JTextField getEjeYTF()
	{
		return ejeYTF;
	}
	public VentanaAñadirPuntos() 
	{
		super("Añadir Puntos", true, true, true, true);
		
		this.setSize(800,300);
		this.setBounds(20, 100 , 650, 460);
		this.setDefaultCloseOperation(JFrame.HIDE_ON_CLOSE);
		crearVentana();
		añadirListeners();	
	}
	
	public void crearVentana() {
		setLayout(new BorderLayout());
		panelCentral 	= new JPanel();
		panelAbajo		= new JPanel();
		
		panelCentral.setLayout(new GridLayout(5,2));
		panelAbajo.setLayout(new GridLayout(2,1));
		
		cabecera		= new JLabel("Introducir los datos para guardarlos en un fichero");
		cabecera.setFont(new Font("Verdana", Font.BOLD, 20));
		cabecera.setHorizontalAlignment(JLabel.CENTER);
		
		titulo 			= new JLabel("Titulo:");
		autor			= new JLabel("Autor:");
		numeroPuntos 	= new JLabel("Numero de puntos:");
		ejeX			= new JLabel("Eje X:");
		ejeY			= new JLabel("Eje Y:");
		
		
		tituloTF		= new JTextField("Introducir el titulo", 20);
		autorTF			= new JTextField("Introducir el autor", 20);
		numeroPuntosTF	= new JTextField("Introducir el numero de puntos", 5);
		ejeXTF			= new JTextField("Introducir el valor del eje X", 5);
		ejeYTF			= new JTextField("Introducir el valor del eje Y", 5);

		ok 				= new JButton("Ok");
		cancelar		= new JButton("Cancelar");
		
		panelCentral.add(titulo); panelCentral.add(tituloTF);
		panelCentral.add(autor); panelCentral.add(autorTF);
		panelCentral.add(ejeX); panelCentral.add(ejeXTF);
		panelCentral.add(ejeY); panelCentral.add(ejeYTF);
		panelCentral.add(numeroPuntos); panelCentral.add(numeroPuntosTF);

		
		panelAbajo.add(ok); panelAbajo.add(cancelar);
		add(cabecera, BorderLayout.NORTH);
		add(panelCentral, BorderLayout.CENTER);
		add(panelAbajo, BorderLayout.SOUTH);
		setVisible(true);
		
	}
	public void añadirListeners()
	{
		System.out.println("Añadidos listener de ventana añadir puntos");
		tituloTF.addFocusListener(Launcher.getCap());
		autorTF.addFocusListener(Launcher.getCap());
		numeroPuntosTF.addFocusListener(Launcher.getCap());
		ejeXTF.addFocusListener(Launcher.getCap());
		ejeYTF.addFocusListener(Launcher.getCap());
		
		ok.addActionListener(Launcher.getCap());
		ok.setActionCommand(OK);
		cancelar.addActionListener(Launcher.getCap());
		cancelar.setActionCommand(CANCELAR);
	}
}
