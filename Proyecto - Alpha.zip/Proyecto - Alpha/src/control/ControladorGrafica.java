package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import view.VentanaEstadisticas;
import view.VentanaGrafica;

public class ControladorGrafica implements ActionListener, ChangeListener 
{
	VentanaGrafica ventana;

	@Override
	public void stateChanged(ChangeEvent eventoCambiado) {
		// TODO Auto-generated method stub
		
	}

	@Override
	public void actionPerformed(ActionEvent evento)
	{
		switch (evento.getActionCommand())
		{
		case "BOTONCALCULARESTADISTICAAC":
			
			break;
		case "BOTONCAMBIARAC":
			
			break;
		case "BOTONMOSTRARESTADISTICAAC":
			VentanaEstadisticas ventanaEstadisticas = new VentanaEstadisticas();
			Launcher.getVentana().getContentPane().add(ventanaEstadisticas);
			
			break;

		default:
			System.out.println("Comando no reconocido - clase ControladorGrafica");
			break;
		}
	}
	
	public void asignarVentana(VentanaGrafica ventana)
	{
		this.ventana = ventana;
	}
	
	public void CalcularLineaRegresion()
	{
		
		
	}

}
