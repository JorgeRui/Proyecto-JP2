package control;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import javax.swing.ImageIcon;
import javax.swing.JColorChooser;
import javax.swing.JDialog;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import model.Punto;
import view.VentanaEstadisticas;
import view.VentanaGrafica;

public class ControladorGrafica implements ActionListener, ChangeListener 
{
	VentanaGrafica ventana;
	private JColorChooser colorChooser;
	private ImageIcon iconoColorChooser;
	private ControladorColorChooser ccc;
	public JColorChooser getColorChooser()
	{
		return colorChooser;
	}
	public ControladorGrafica(ControladorColorChooser ccc)
	{
		this.ccc = ccc;
		colorChooser = new JColorChooser(Color.BLACK);
		iconoColorChooser = new ImageIcon("Imagenes/ColorPickerIcon.png");
	}
	/**
	 * Controlar los checkbox
	 */
	@Override
	public void stateChanged(ChangeEvent eventoCambiado) 
	{
		
	}

	@Override
	public void actionPerformed(ActionEvent evento)
	{
		switch (evento.getActionCommand())
		{
		case "BOTONCALCULARESTADISTICAAC":
			//TODO Aqui se calcula la estadistica
			break;
		case "BOTONCAMBIARCOLORAC":
			JDialog cc = JColorChooser.createDialog(null, "Color de los puntos", true, colorChooser, ccc, null);

			cc.setIconImage(iconoColorChooser.getImage());
			cc.setVisible(true);
			break;
		case "BOTONMOSTRARESTADISTICAAC":
			VentanaEstadisticas ventanaEstadisticas = new VentanaEstadisticas();
			Launcher.getCe().añadirVentana(ventanaEstadisticas);
			
			Launcher.getCe().calcularX(sacarX(Launcher.getCpi().getPuntos()));
			Launcher.getCe().calcularY(sacarY(Launcher.getCpi().getPuntos()));
			Launcher.getVentana().getContentPane().add(ventanaEstadisticas);
			
			Launcher.getVentanaLog().añadirLog("Mostrando ventana estadisticas");
			break;

		default:
			System.out.println("Comando no reconocido - clase ControladorGrafica");
			break;
		}
	}
	
	public void asignarVentana(VentanaGrafica ventana)
	{
		this.ventana = ventana;
	}
	
	////////////////////////////////////////////////////////////////////////////////
	
	public Vector<Double> sacarX(Vector<Punto> puntos)
	{
		Vector<Double> valoresX = new Vector<Double>();
		for (int i = 0; i < puntos.size(); i++) 
		{
			valoresX.add(i, puntos.get(i).getX());
		}
		return valoresX;
	}
	public Vector<Double> sacarY(Vector<Punto> puntos)
	{
		Vector<Double> valoresY = new Vector<Double>();
		for (int i = 0; i < puntos.size(); i++) 
		{
			valoresY.add(i, puntos.get(i).getY());
		}
		return valoresY;
	}
}
