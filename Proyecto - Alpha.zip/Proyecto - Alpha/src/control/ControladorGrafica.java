package control;

import java.awt.Color;
import java.awt.Graphics2D;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.image.BufferedImage;
import java.io.File;
import java.io.IOException;
import java.util.Vector;

import javax.imageio.ImageIO;
import javax.swing.ImageIcon;
import javax.swing.JCheckBox;
import javax.swing.JColorChooser;
import javax.swing.JDialog;
import javax.swing.JOptionPane;
import javax.swing.JPanel;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

import model.Punto;
import view.VentanaEstadisticas;
import view.VentanaGrafica;

public class ControladorGrafica implements ActionListener, ChangeListener 
{
	VentanaGrafica ventana;
	private JColorChooser colorChooser;
	private ImageIcon iconoColorChooser;
	private ControladorColorChooser ccc;
	public JColorChooser getColorChooser()
	{
		return colorChooser;
	}
	public ControladorGrafica(ControladorColorChooser ccc)
	{
		this.ccc = ccc;
		colorChooser = new JColorChooser(Color.BLACK);
		iconoColorChooser = new ImageIcon("Imagenes/ColorPickerIcon.png");
	}
	/**
	 * Controlar los checkbox: mostrarValor, mostrarEjes, mostrarLineaRegresion;
	 */
	@Override
	public void stateChanged(ChangeEvent eventoCambiado) 
	{
		//FIXME: TODO: Falta arreglar estos controlados
		JCheckBox checkbox = (JCheckBox) eventoCambiado.getSource();
		if (checkbox == ventana.mostrarValor && checkbox.isSelected())
		{
			ventana.getPaintPanel().setMostrarValor(true);
			ventana.getPaintPanel().repaint();
		}
		else
		{
			ventana.getPaintPanel().setMostrarValor(false);
			ventana.getPaintPanel().repaint();
		}
		
		if(checkbox == ventana.mostrarEjes && checkbox.isSelected() )
		{
			ventana.getPaintPanel().setMostrarEjes(true);
			ventana.getPaintPanel().repaint();
		}
		else
		{
			ventana.getPaintPanel().setMostrarEjes(false);
			ventana.getPaintPanel().repaint();
		}
		if (checkbox == ventana.lineaRegresion && checkbox.isSelected())
		{
			ventana.getPaintPanel().setMostrarLineaRegresion(true);
			ventana.getPaintPanel().repaint();
		}
		else
		{
			ventana.getPaintPanel().setMostrarLineaRegresion(false);
			ventana.getPaintPanel().repaint();
		}
	}

	@Override
	public void actionPerformed(ActionEvent evento)
	{
		switch (evento.getActionCommand())
		{
		case "BOTONGUARDARIMAGENAC":
			BufferedImage imagen = guardarImagen(Launcher.getVentanaG().getPaintPanel());
			try 
			{
				Launcher.getVentanaLog().añadirLog("Imagen de la grafica guardada");
				Launcher.getVentanaG().cambiarLabelAyuda("Guardada imagen de la grafica", 1);
				ImageIO.write(imagen, "jpg", new File("Grafica creada.jpg"));
			} catch (IOException e) 
			{
				System.out.println("Error de escritura");
			}

			break;
		case "BOTONCAMBIARCOLORAC":
			JDialog cc = JColorChooser.createDialog(null, "Color de los puntos", true, colorChooser, ccc, null);

			cc.setIconImage(iconoColorChooser.getImage());
			cc.setVisible(true);
			break;
		case "BOTONMOSTRARESTADISTICAAC":
			if (Launcher.getCpi().getPuntos() == null)
			{
				Launcher.getVentanaLog().añadirLog("No hay puntos guardados");
				Launcher.getVentanaG().cambiarLabelAyuda("No hay puntos guardados para mostrar estadisticas", 2);
				JOptionPane.showMessageDialog(Launcher.getVentana().getContentPane(),"No hay puntos leidos del archivo aun, importe primero los puntos.", "Error - Puntos no encontrados",JOptionPane.ERROR_MESSAGE);
				return;
			}
			VentanaEstadisticas ventanaEstadisticas = new VentanaEstadisticas();
			Launcher.getCe().añadirVentana(ventanaEstadisticas);
			
			Launcher.getCe().calcularX(sacarX(Launcher.getCpi().getPuntos()));
			Launcher.getCe().calcularY(sacarY(Launcher.getCpi().getPuntos()));
			Launcher.getCe().calcularCorrelacion();
			
			Launcher.getVentana().getContentPane().add(ventanaEstadisticas);
			
			Launcher.getVentanaLog().añadirLog("Mostrando ventana estadisticas");
			break;
		case "BOTONLINEAREGRESIONAC":
			Launcher.getVentanaG().getPaintPanel().setPuntosLineaRegresion(Launcher.getCe().calcularLineaRegresion(pasarArrayVectorDouble(Launcher.getCpi().x), pasarArrayVectorDouble(Launcher.getCpi().y)));
			System.out.println("Puntos pasados a la linea de regresion con éxito");
			break;
		default:
			System.out.println("Comando no reconocido - clase ControladorGrafica");
			break;
		}
	}
	
	public void asignarVentana(VentanaGrafica ventana)
	{
		this.ventana = ventana;
	}
	
	////////////////////////////////////////////////////////////////////////////////
	
	public Vector<Double> sacarX(Vector<Punto> puntos)
	{
		Vector<Double> valoresX = new Vector<Double>();
		for (int i = 0; i < puntos.size(); i++) 
		{
			valoresX.add(i, puntos.get(i).getX());
		}
		return valoresX;
	}
	public Vector<Double> sacarY(Vector<Punto> puntos)
	{
		Vector<Double> valoresY = new Vector<Double>();
		for (int i = 0; i < puntos.size(); i++) 
		{
			valoresY.add(i, puntos.get(i).getY());
		}
		return valoresY;
	}
	
	public Vector<Double> pasarArrayVectorDouble(double[] valores)
	{
		Vector<Double> resultado = new Vector<Double>();
		for (int i = 0; i < valores.length; i++) {
			resultado.add(valores[i]);
		}
		return resultado;
	}
	public BufferedImage guardarImagen(JPanel panel)
	{

	    int with = panel.getWidth();
	    int height = panel.getHeight();
	    BufferedImage imagen = new BufferedImage(with, height, BufferedImage.TYPE_INT_RGB);
	    Graphics2D g = imagen.createGraphics();
	    panel.paint(g);
	    
	    return imagen;
	}

}
