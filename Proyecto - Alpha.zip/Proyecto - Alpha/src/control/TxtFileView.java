package control;

import java.io.File;

import javax.swing.Icon;
import javax.swing.ImageIcon;
import javax.swing.filechooser.FileView;

class TxtFileView extends FileView
{
	Icon txtIcon	 = new ImageIcon("Imagenes/txtIco.png");
	Icon carpetaIcon = new ImageIcon("Imagenes/carpetaIco.png");

	/**
	 * 
	 */
	public String getTypeDescription(File archivo)
	{
		String descripcionTipo = null;
		String nombreArchivo = archivo.getName().toLowerCase();

		if (nombreArchivo.endsWith(".txt") || nombreArchivo.endsWith(".TXT"))
		{
			descripcionTipo = "Archivo de texto";
		}

		return descripcionTipo;
	}
	
	
	/**
	 * 
	 */
	
	public Icon getIcon(File archivo) 
	{
		Icon icon = null;
		String nombreArchivo = archivo.getName().toLowerCase();
		if (nombreArchivo.endsWith(".txt"))
		{
			icon = txtIcon;
		}
		else if (archivo.isDirectory()) 
		{
			icon = carpetaIcon;
		}
		return icon;
	}

}
