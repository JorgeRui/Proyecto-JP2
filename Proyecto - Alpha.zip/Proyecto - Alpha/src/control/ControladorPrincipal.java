package control;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.geom.AffineTransform;
import java.io.File;
import java.util.Vector;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

import model.Escala;
import model.Punto;
import view.VentanaAyuda;
import view.VentanaAñadirPuntos;
import view.VentanaMostrarPuntos;
import view.VentanaPrincipal;

public class ControladorPrincipal implements ActionListener
{
	VentanaPrincipal ventanaPrincipal;
	VentanaAñadirPuntos ventanaAñadirPuntos;
	VentanaMostrarPuntos ventanaMostrarPuntos;
	TxtFileView fileView;
	JFileChooser fileChooser;
	String lecturaFichero;
	FileNameExtensionFilter filtro;
	Archivo archivo;
	String directorioUsuario = System.getProperty("user.home");
	
	Vector<Punto> puntos;
	
	//ESCALADO DE GRAFICOS:
	Escala escala;
	AffineTransform escalado;
	/////
	public String ejeX, ejeY;
	int[] pixelesX, pixelesY;
	double[] x, y;
	int seleccion;
	
	public VentanaAñadirPuntos getVentanaAñadirPuntos()
	{
		return ventanaAñadirPuntos;
	}
	public Archivo getArchivo()
	{
		return archivo;
	}
	
	public Vector<Punto> getPuntos()
	{
		return puntos;
	}
	public ControladorPrincipal()
	{
		fileChooser = new JFileChooser(directorioUsuario +"/Desktop");
		archivo		= new Archivo();
		filtro 		= new FileNameExtensionFilter("*.TXT", "txt");
		fileView 	= new TxtFileView();
		escala		= new Escala();
		
		escalado = new AffineTransform(); 

	}
	@Override
	public void actionPerformed(ActionEvent evento) 
	{
		switch (evento.getActionCommand())
		{
		case "ANAC":
			
			fileChooser.setFileView(fileView);
			fileChooser.setApproveButtonText("Cargar archivo");
			fileChooser.setDialogTitle("Archivos");
			fileChooser.setCurrentDirectory(new File("C:\\Users\\User\\Desktop"));
			fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			fileChooser.setPreferredSize(new Dimension(800,800));

			//Le indicamos el filtro
			fileChooser.setFileFilter(filtro);
			seleccion = fileChooser.showOpenDialog(ventanaPrincipal.getMenuItemAbrir());

			//Si el usuario, pincha en aceptar
			if(seleccion==JFileChooser.APPROVE_OPTION)
			{
				//Seleccionamos el fichero
				archivo.setFichero(fileChooser.getSelectedFile());
				lecturaFichero = fileChooser.getSelectedFile().getAbsolutePath();

				System.out.println("Abriendo: " + lecturaFichero);
				puntos = Archivo.LeerArchivo();
				if (puntos == null) 
				{
					System.out.println("Error! los puntos son null - Clase ControladorPrincipal");
				}
				//VARIABLES TEMPORALES:
				int alto, ancho;
				double xMin, xMax, yMin, yMax;
				alto  = ventanaPrincipal.getVentanaGrafica().getPaintPanel().getHeight();
				ancho = ventanaPrincipal.getVentanaGrafica().getPaintPanel().getWidth();
				System.out.println("Alto:" + alto + " Ancho: " + ancho);
				xMin = -calcularValorMasGrandeX(puntos);
				xMax = calcularValorMasGrandeX(puntos);
				yMin = -calcularValorMasGrandeY(puntos);
				yMax = calcularValorMasGrandeY(puntos);
				
				System.out.println("xMin: " + xMin + " xMax: " + xMax + " yMin: " + yMin + " yMax: " + yMax);
				escala.tomarExtremos(xMin, xMax, yMin, yMax);		
				escala.tomarAreaGrafica(ancho, alto);

				pixelesX = new int[puntos.size()];
				pixelesY = new int[puntos.size()];
				for (int i = 0; i < puntos.size(); i++) 
				{
					pixelesX[i] = escala.dameX(puntos.get(i).getX());
					System.out.println("Pixeles: " + i + " :" + pixelesX[i]);
				}
				for (int i = 0; i < puntos.size(); i++) 
				{
					pixelesY[i] = escala.dameY(puntos.get(i).getY());
					System.out.println("Pixeles: " + i + " :" + pixelesX[i]);
				}
				
				
				ventanaPrincipal.getVentanaGrafica().getPaintPanel().setPuntos(pasarArrayVectorPuntos(pixelesX,pixelesY));
				System.out.println(Launcher.getVentanaG().getPaintPanel().getPuntos().toString());
				ventanaPrincipal.getVentanaGrafica().getPaintPanel().setEjeX(ejeX);
				ventanaPrincipal.getVentanaGrafica().getPaintPanel().setEjeY(ejeY);
				ventanaPrincipal.getVentanaGrafica().getPaintPanel().repaint();
			}
			else
			{
				Launcher.getVentanaG().cambiarLabelAyuda("Apertura del archivo cancelada por el usuario", 2);
				System.out.println("Apertura del archivo cancelada por el usuario");
			}

			break;
		case "ANADIRPUNTOSAC":
			ventanaAñadirPuntos = new VentanaAñadirPuntos();
			ventanaPrincipal.getContentPane().add(ventanaAñadirPuntos);
			break;
		case "MOSTRARPUNTOSAC":
			if (puntos == null)
			{
				//El numero indica el tipo de mensaje 
				Launcher.getVentanaLog().añadirLog("No hay puntos reconocidos");
				Launcher.getVentanaG().cambiarLabelAyuda("No hay puntos reconocidos", 2);
				JOptionPane.showMessageDialog(ventanaPrincipal.getContentPane(),"No hay puntos leidos del archivo aun, importe primero los puntos.", "Error - Puntos no encontrados",JOptionPane.ERROR_MESSAGE);
				return;
			}
			ventanaMostrarPuntos = new VentanaMostrarPuntos();
			ventanaMostrarPuntos.setPuntos(puntos);
			ventanaMostrarPuntos.crearVentana();
			ventanaPrincipal.getContentPane().add(ventanaMostrarPuntos);
			
			break;
		case "MOSTRARLOGAC":
			if (Launcher.getVentanaLog().isVisible() == true)
			{
				return;
						
			} else 
			{
				Launcher.getVentanaLog().setVisible(true);
			}
			break;
		case "MOSTRARAYUDAAC":
			VentanaAyuda ventanaAyuda = new VentanaAyuda();
			
			ventanaPrincipal.getContentPane().add(ventanaAyuda);
			break;
			
		case "MOSTRARGRAFICA":
			Launcher.getVentanaLog().añadirLog("Mostrando grafica");
			Launcher.getVentanaG().setVisible(true);
			break;
		default:
			System.out.println("Comando irreconocido");
			break;
		}

	}
	//METODOS DE AYUDA - Mirar si tiene que ser <= o < 
	public void pasarVectorArray(Vector<Punto> puntos){
		x = new double[puntos.size()];
		y = new double[puntos.size()];
		for (int i = 0; i < puntos.size(); i++) 
		{
			x[i] = puntos.get(i).getX();
			y[i] = puntos.get(i).getY();
		}
	}
	
	public double calcularValorMasGrandeX(Vector<Punto> puntos)
	{
		double valorMasGrande, minimo, maximo;
		minimo = calcularMinimoX(puntos);
		maximo = calcularMaximoX(puntos);
		
		if (Math.abs(minimo) > Math.abs(maximo))
		{
			valorMasGrande = minimo;
		}
		else
		{
			valorMasGrande = maximo;
		}
		return valorMasGrande;
	}
	public double calcularValorMasGrandeY(Vector<Punto> puntos)
	{
		double valorMasGrande, minimo, maximo;
		minimo = calcularMinimoY(puntos);
		maximo = calcularMaximoY(puntos);
		
		if (Math.abs(minimo) > Math.abs(maximo))
		{
			valorMasGrande = minimo;
		}
		else
		{
			valorMasGrande = maximo;
		}
		
		return valorMasGrande;
	}

	public Vector<Punto> pasarArrayVectorPuntos(int[] x, int[] y){
		Vector<Punto> puntos = new Vector<Punto>();
		for (int i = 0; i < x.length; i++) 
		{
			Punto p = new Punto(x[i], y[i]);
			puntos.addElement(p);
		}
		
		return puntos;
	}
	
	public double calcularMinimoX(Vector<Punto> puntos)
	{
		double minimo = puntos.get(0).getX();
		for (int i = 0; i < puntos.size(); i++)
		{
			if (puntos.get(i).getX() < minimo)
			{
				minimo = puntos.get(i).getX();
			}
		}
		return minimo;
	}
	public double calcularMaximoX(Vector<Punto> puntos)
	{
		double maximo = puntos.get(0).getX();
		for (int i = 0; i < puntos.size(); i++)
		{
			if (puntos.get(i).getX() > maximo)
			{
				maximo = puntos.get(i).getX();
			}
		}

		return maximo;
	}
	public double calcularMinimoY(Vector<Punto> puntos)
	{
		double minimo = puntos.get(0).getY();
		for (int i = 0; i < puntos.size(); i++)
		{
			if (puntos.get(i).getY() < minimo)
			{
				minimo = puntos.get(i).getY();
			}
		}
		return minimo;
	}
	public double calcularMaximoY(Vector<Punto> puntos)
	{
		double maximo = puntos.get(0).getY();
		for (int i = 0; i < puntos.size(); i++)
		{
			if (puntos.get(i).getY() > maximo)
			{
				maximo = puntos.get(i).getY();
			}
		}
		return maximo;
	}
	
	public void asignarVentana(VentanaPrincipal ventanaPrincipal)
	{
		this.ventanaPrincipal = ventanaPrincipal;
	}
}
