package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;

public class ControladorPrincipal implements ActionListener, ChangeListener 
{

	@Override
	public void actionPerformed(ActionEvent evento)
	{
		switch (evento.getActionCommand()) {
		case "BOTONESTADISTICAAC":
			
			break;
		case "BOTONCAMBIARAC":
			
			break;
		case "BOTONMOSTRARESTADISTICAAC":
			
			break;
		default:
			System.out.println("Comando irreconocido");
			break;
		}
	}

	@Override
	public void stateChanged(ChangeEvent eventoCambiado) {
		// TODO Auto-generated method stub
		
	}

}
