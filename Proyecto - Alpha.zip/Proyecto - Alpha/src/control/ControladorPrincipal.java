package control;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Vector;

import javax.swing.JFileChooser;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileNameExtensionFilter;

import model.Escala;
import model.Punto;
import view.VentanaAñadirPuntos;
import view.VentanaEstadisticas;
import view.VentanaPrincipal;

public class ControladorPrincipal implements ActionListener, ChangeListener 
{
	VentanaPrincipal ventana;
	TxtFileView fileView;
	JFileChooser fileChooser;
	String lecturaFichero;
	FileNameExtensionFilter filtro;
	Archivo archivo;
	int seleccion;
	String directorioUsuario = System.getProperty("user.home");
	
	Vector<Punto> puntos;
	Escala escala;
	int[] pixelesX, pixelesY, x, y;
	public ControladorPrincipal()
	{
		fileChooser = new JFileChooser(directorioUsuario +"/Desktop");
		archivo		= new Archivo();
		filtro 		= new FileNameExtensionFilter("*.TXT", "txt");
		fileView 	= new TxtFileView();
		escala		= new Escala();
	}

	@Override
	public void actionPerformed(ActionEvent evento) {

		switch (evento.getActionCommand()) 
		{
		case "BEAC":

			break;
		case "BCAC":

			break;
		case "BMEAC":
			//FIXME FIXME FIXME TODO SALE DETR�S DEL PAINT PANEL!!!
			VentanaEstadisticas ventanaEstadisticas = new VentanaEstadisticas();
			ventanaEstadisticas.crearVentana();
			break;
		case "ANAC":

			fileChooser.setFileView(fileView);
			fileChooser.setApproveButtonText("Cargar archivo");
			fileChooser.setDialogTitle("Archivos");
			fileChooser.setCurrentDirectory(new File("C:\\Users\\User\\Desktop"));
			fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			fileChooser.setPreferredSize(new Dimension(800,800));

			//Le indicamos el filtro
			fileChooser.setFileFilter(filtro);
			seleccion = fileChooser.showOpenDialog(ventana.getMenuItemAbrir());

			//Si el usuario, pincha en aceptar
			if(seleccion==JFileChooser.APPROVE_OPTION)
			{
				//Seleccionamos el fichero
				archivo.setFichero(fileChooser.getSelectedFile());
				lecturaFichero = fileChooser.getSelectedFile().getAbsolutePath();

				System.out.println("Abriendo: " + lecturaFichero);
				puntos = Archivo.LeerArchivo();
				if (puntos == null) 
				{
					System.out.println("Error! los puntos son null - Clase ControladorPrincipal");
				}
				escala.tomarExtremos(0, 20, -20, 20);
				escala.tomarAreaGrafica(ventana.getPaintPanel().getWidth(), ventana.getPaintPanel().getHeight());
				
				pixelesX = escala.dameX(puntos, 10);
				pixelesY = escala.dameY(puntos, 10);
				ventana.getPaintPanel().setPuntos(pasarArrayVector(pixelesX,pixelesY));
				ventana.getPaintPanel().repaint();
			}
			else {
				System.out.println("Apertura del archivo cancelada por el usuario");
			}

			break;
		case "ANADIRPUNTOSAC":
			//FIXME FIXME FIXME TODO SALE DETR�S DEL PAINT PANEL!!!
			VentanaAñadirPuntos ventanaAñadirPuntos = new VentanaAñadirPuntos();
			ventanaAñadirPuntos.crearVentana();
			//ventana.getContentPane().add(ventanaAñadirPuntos);
			break;
		default:
			System.out.println("Comando irreconocido");
			break;
		}

	}
	
	@Override
	public void stateChanged(ChangeEvent eventoCambiado) {
		// TODO Auto-generated method stub

	}

	public void asignarVentana(VentanaPrincipal ventana)
	{
		this.ventana = ventana;
	}
	
	/**
	 * Metodo que sirve para pasar de un vector a un array de puntos
	 * @param puntos
	 */
	public void pasarVectorArray(Vector<Punto> puntos)
	{
		x = new int[puntos.size()];
		y = new int[puntos.size()];
		for (int i = 0; i < puntos.size(); i++) 
		{
			x[i] = (int) puntos.get(i).getX();
			y[i] = (int) puntos.get(i).getY();
		}
	}
	/**
	 * Metodo que se encarga de pasar dos arrays a un vector de puntos
	 * @param x el array de valores x
	 * @param y el array de valores y
	 * @return devuelve el vector de puntos, con sus componentes x e y
	 */
	public Vector<Punto> pasarArrayVector(int[] x, int[] y)
	{
		Vector<Punto> puntos = new Vector<Punto>();
		for (int i = 0; i < x.length; i++) 
		{
			Punto p = new Punto(x[i], y[i]);
			puntos.addElement(p);
		}
		
		return puntos;
	}

}
