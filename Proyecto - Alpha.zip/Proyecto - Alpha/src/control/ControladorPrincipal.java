package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;

import javax.swing.JFileChooser;
import javax.swing.JMenuItem;
import javax.swing.event.ChangeEvent;
import javax.swing.event.ChangeListener;
import javax.swing.filechooser.FileNameExtensionFilter;

public class ControladorPrincipal implements ActionListener, ChangeListener 
{
	private JMenuItem jMenuItem;
	public ControladorPrincipal(JMenuItem jMenuItem){
		this.jMenuItem = jMenuItem;
	}
	@Override
	public void actionPerformed(ActionEvent evento)
	{
		
		////
		///
		
		if(jMenuItem.getText() == "Abrir..."){
			JFileChooser fc = new JFileChooser();
			fc.setDialogTitle("Archivos");
	
			//Creamos el filtro
		    FileNameExtensionFilter filtro = new FileNameExtensionFilter("*.TXT", "txt");
		     
		    //Le indicamos el filtro
		    fc.setFileFilter(filtro);

			int seleccion=fc.showOpenDialog(jMenuItem);
			 
			//Si el usuario, pincha en aceptar
			if(seleccion==JFileChooser.APPROVE_OPTION){
			 
			    //Seleccionamos el fichero
			    File fichero= fc.getSelectedFile();
			    
			  String lecturaFichero;
			  lecturaFichero = fc.getSelectedFile().getAbsolutePath();
			  
			  System.out.println(lecturaFichero);
			    
		}
			
	}
		
		//
		
		switch (evento.getActionCommand()) {
		case "BOTONESTADISTICAAC":
			
			break;
		case "BOTONCAMBIARAC":
			
			break;
		case "BOTONMOSTRARESTADISTICAAC":
			
			break;
		default:
			System.out.println("Comando irreconocido");
			break;
		}
	
	}

	@Override
	public void stateChanged(ChangeEvent eventoCambiado) {
		// TODO Auto-generated method stub
		
	}

}
