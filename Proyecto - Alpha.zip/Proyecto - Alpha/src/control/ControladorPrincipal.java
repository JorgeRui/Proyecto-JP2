package control;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Vector;

import javax.swing.JFileChooser;
import javax.swing.JOptionPane;
import javax.swing.filechooser.FileNameExtensionFilter;

import model.Escala;
import model.Punto;
import view.VentanaAyuda;
import view.VentanaAñadirPuntos;
import view.VentanaMostrarPuntos;
import view.VentanaPrincipal;

public class ControladorPrincipal implements ActionListener
{
	VentanaPrincipal ventanaPrincipal;
	VentanaAñadirPuntos ventanaAñadirPuntos;
	VentanaAyuda ventanaAyuda;
	VentanaMostrarPuntos ventanaMostrarPuntos;
	TxtFileView fileView;
	JFileChooser fileChooser;
	String lecturaFichero;
	FileNameExtensionFilter filtro;
	static Archivo archivo;
	String directorioUsuario = System.getProperty("user.home");
	
	Vector<Punto> puntos;
	Escala escala;
	int[] pixelesX, pixelesY, x, y;
	int seleccion;
	
	public VentanaAñadirPuntos getVentanaAñadirPuntos()
	{
		return ventanaAñadirPuntos;
	}
	public static Archivo getArchivo()
	{
		return archivo;
	}
	
	public ControladorPrincipal()
	{
		fileChooser = new JFileChooser(directorioUsuario +"/Desktop");
		archivo		= new Archivo();
		filtro 		= new FileNameExtensionFilter("*.TXT", "txt");
		fileView 	= new TxtFileView();
		escala		= new Escala();
	}
	@Override
	public void actionPerformed(ActionEvent evento) 
	{
		switch (evento.getActionCommand())
		{
		case "ANAC":
			
			fileChooser.setFileView(fileView);
			fileChooser.setApproveButtonText("Cargar archivo");
			fileChooser.setDialogTitle("Archivos");
			fileChooser.setCurrentDirectory(new File("C:\\Users\\User\\Desktop"));
			fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			fileChooser.setPreferredSize(new Dimension(800,800));

			//Le indicamos el filtro
			fileChooser.setFileFilter(filtro);
			seleccion = fileChooser.showOpenDialog(ventanaPrincipal.getMenuItemAbrir());

			//Si el usuario, pincha en aceptar
			if(seleccion==JFileChooser.APPROVE_OPTION)
			{
				//Seleccionamos el fichero
				archivo.setFichero(fileChooser.getSelectedFile());
				lecturaFichero = fileChooser.getSelectedFile().getAbsolutePath();

				System.out.println("Abriendo: " + lecturaFichero);
				puntos = Archivo.LeerArchivo();
				if (puntos == null) 
				{
					System.out.println("Error! los puntos son null - Clase ControladorPrincipal");
				}
				escala.tomarExtremos(calcularMinimoX(puntos), calcularMaximoX(puntos), calcularMinimoY(puntos), calcularMaximoY(puntos));
				escala.tomarAreaGrafica(ventanaPrincipal.getVentanaGrafica().getPaintPanel().getWidth(), ventanaPrincipal.getVentanaGrafica().getPaintPanel().getHeight());
				//FIXME: Cambiar esto, el 10 es arbitrario y no deberia ser así
				pixelesX = escala.dameX(puntos, 15);
				pixelesY = escala.dameY(puntos, 15);
				ventanaPrincipal.getVentanaGrafica().getPaintPanel().setPuntos(pasarArrayVector(pixelesX,pixelesY));
				ventanaPrincipal.getVentanaGrafica().getPaintPanel().repaint();
			}
			else
			{
				Launcher.getVentanaG().cambiarLabelAyuda("Apertura del archivo cancelada por el usuario", 2);
				System.out.println("Apertura del archivo cancelada por el usuario");
			}

			break;
		case "ANADIRPUNTOSAC":
			ventanaAñadirPuntos = new VentanaAñadirPuntos();
			ventanaPrincipal.getContentPane().add(ventanaAñadirPuntos);
			break;
		case "MOSTRARPUNTOSAC":
			if (puntos == null)
			{
				Launcher.getVentanaG().cambiarLabelAyuda("No hay puntos reconocidos", 2);
				JOptionPane.showMessageDialog(ventanaPrincipal.getContentPane(),"No hay puntos leidos del archivo aun, importe primero los puntos.", "Error - Puntos no encontrados",JOptionPane.ERROR_MESSAGE);
				return;
			}
			ventanaMostrarPuntos = new VentanaMostrarPuntos();
			ventanaMostrarPuntos.setPuntos(puntos);
			ventanaMostrarPuntos.crearVentana();
			ventanaPrincipal.getContentPane().add(ventanaMostrarPuntos);
			
			break;
		case "AYUDAAC":
			ventanaAyuda = new VentanaAyuda();
			Launcher.getCa().asignarVentana(ventanaAyuda);
			ventanaPrincipal.getContentPane().add(ventanaAyuda);
			break;
		case "MOSTRARGRAFICA":
			System.out.println("Mostrando Grafica");
			Launcher.getVentanaG().setVisible(true);
			break;
		default:
			System.out.println("Comando irreconocido");
			break;
		}

	}
	//METODOS DE AYUDA - Mirar si tiene que ser <= o < 
	public void pasarVectorArray(Vector<Punto> puntos)
	{
		x = new int[puntos.size()];
		y = new int[puntos.size()];
		for (int i = 0; i < puntos.size(); i++) 
		{
			x[i] = (int) puntos.get(i).getX();
			y[i] = (int) puntos.get(i).getY();
		}
	}
	
	public Vector<Punto> pasarArrayVector(int[] x, int[] y)
	{
		Vector<Punto> puntos = new Vector<Punto>();
		for (int i = 0; i < x.length; i++) 
		{
			Punto p = new Punto(x[i], y[i]);
			puntos.addElement(p);
		}
		
		return puntos;
	}
	
	public double calcularMinimoX(Vector<Punto> puntos)
	{
		double minimo = puntos.get(0).getX();
		for (int i = 0; i < puntos.size(); i++)
		{
			if (puntos.get(i).getX() < minimo)
			{
				minimo = puntos.get(i).getX();
			}
		}
		System.out.println("El valor minimo de X es: " + minimo);
		return minimo * 1.1;
	}
	public double calcularMaximoX(Vector<Punto> puntos)
	{
		double maximo = puntos.get(0).getX();
		for (int i = 0; i < puntos.size(); i++)
		{
			if (puntos.get(i).getX() > maximo)
			{
				maximo = puntos.get(i).getX();
			}
		}
		System.out.println("El valor maximo de X es: " + maximo);

		return maximo * 1.1;
	}
	public double calcularMinimoY(Vector<Punto> puntos)
	{
		double minimo = puntos.get(0).getY();
		for (int i = 0; i < puntos.size(); i++)
		{
			if (puntos.get(i).getY() < minimo)
			{
				minimo = puntos.get(i).getY();
			}
		}
		System.out.println("El valor minimo de Y es: " + minimo);

		return minimo * 1.1;
	}
	public double calcularMaximoY(Vector<Punto> puntos)
	{
		double maximo = puntos.get(0).getY();
		for (int i = 0; i < puntos.size(); i++)
		{
			if (puntos.get(i).getY() > maximo)
			{
				maximo = puntos.get(i).getY();
			}
		}
		System.out.println("El valor maximo de Y es: " + maximo);
		return maximo * 1.1;
	}
	
	public void asignarVentana(VentanaPrincipal ventanaPrincipal)
	{
		this.ventanaPrincipal = ventanaPrincipal;
	}
}
