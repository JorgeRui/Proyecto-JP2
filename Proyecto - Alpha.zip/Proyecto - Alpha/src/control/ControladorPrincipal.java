package control;

import java.awt.Dimension;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.io.File;
import java.util.Vector;

import javax.swing.JFileChooser;
import javax.swing.filechooser.FileNameExtensionFilter;

import model.Escala;
import model.Punto;
import view.VentanaAñadirPuntos;
import view.VentanaPrincipal;

public class ControladorPrincipal implements ActionListener
{
	VentanaPrincipal ventanaPrincipal;
	
	TxtFileView fileView;
	JFileChooser fileChooser;
	String lecturaFichero;
	FileNameExtensionFilter filtro;
	Archivo archivo;
	int seleccion;
	String directorioUsuario = System.getProperty("user.home");
	
	Vector<Punto> puntos;
	Escala escala;
	int[] pixelesX, pixelesY, x, y;
	
	public ControladorPrincipal()
	{
		fileChooser = new JFileChooser(directorioUsuario +"/Desktop");
		archivo		= new Archivo();
		filtro 		= new FileNameExtensionFilter("*.TXT", "txt");
		fileView 	= new TxtFileView();
		escala		= new Escala();
	}
	@Override
	public void actionPerformed(ActionEvent evento) 
	{
		System.out.println("Evento registrado en ControladorPrincipal");
		switch (evento.getActionCommand())
		{
		case "ANAC":

			fileChooser.setFileView(fileView);
			fileChooser.setApproveButtonText("Cargar archivo");
			fileChooser.setDialogTitle("Archivos");
			fileChooser.setCurrentDirectory(new File("C:\\Users\\User\\Desktop"));
			fileChooser.setFileSelectionMode(JFileChooser.FILES_ONLY);
			fileChooser.setPreferredSize(new Dimension(800,800));

			//Le indicamos el filtro
			fileChooser.setFileFilter(filtro);
			seleccion = fileChooser.showOpenDialog(ventanaPrincipal.getMenuItemAbrir());

			//Si el usuario, pincha en aceptar
			if(seleccion==JFileChooser.APPROVE_OPTION)
			{
				//Seleccionamos el fichero
				archivo.setFichero(fileChooser.getSelectedFile());
				lecturaFichero = fileChooser.getSelectedFile().getAbsolutePath();

				System.out.println("Abriendo: " + lecturaFichero);
				puntos = Archivo.LeerArchivo();
				if (puntos == null) 
				{
					System.out.println("Error! los puntos son null - Clase ControladorPrincipal");
				}
				escala.tomarExtremos(0, 20, -20, 20);
				escala.tomarAreaGrafica(ventanaPrincipal.getVentanaGrafica().getPaintPanel().getWidth(), ventanaPrincipal.getVentanaGrafica().getPaintPanel().getHeight());
				
				pixelesX = escala.dameX(puntos, 10);
				pixelesY = escala.dameY(puntos, 10);
				ventanaPrincipal.getVentanaGrafica().getPaintPanel().setPuntos(pasarArrayVector(pixelesX,pixelesY));
				ventanaPrincipal.getVentanaGrafica().getPaintPanel().repaint();
			}
			else {
				System.out.println("Apertura del archivo cancelada por el usuario");
			}

			break;
		case "ANADIRPUNTOSAC":
			VentanaAñadirPuntos ventanaAñadirPuntos = new VentanaAñadirPuntos();
			ventanaAñadirPuntos.crearVentana();
			ventanaPrincipal.getContentPane().add(ventanaAñadirPuntos);
			break;
		case "MOSTRARPUNTOSAC":
			break;
		case "AYUDAAC":
			break;
		case "MOSTRARGRAFICA":
			System.out.println("Mostrando Grafica");
			Launcher.getVentanaG().setVisible(true);
			break;
		default:
			System.out.println("Comando irreconocido");
			break;
		}

	}
	
	public void pasarVectorArray(Vector<Punto> puntos)
	{
		x = new int[puntos.size()];
		y = new int[puntos.size()];
		for (int i = 0; i < puntos.size(); i++) 
		{
			x[i] = (int) puntos.get(i).getX();
			y[i] = (int) puntos.get(i).getY();
		}
	}
	
	public Vector<Punto> pasarArrayVector(int[] x, int[] y)
	{
		Vector<Punto> puntos = new Vector<Punto>();
		for (int i = 0; i < x.length; i++) 
		{
			Punto p = new Punto(x[i], y[i]);
			puntos.addElement(p);
		}
		
		return puntos;
	}
	
	public void asignarVentana(VentanaPrincipal ventanaPrincipal)
	{
		this.ventanaPrincipal = ventanaPrincipal;
	}
}
