package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JTextField;

public class ControladorA�adirPuntos implements FocusListener, ActionListener 
{

	
	@Override
	public void actionPerformed(ActionEvent evento)
	{
		switch (evento.getActionCommand()) {
		case "OK":
			System.out.println("TODO OK");
			break;
		case "CANCELAR":
			System.out.println("Cancelado");
			break;
		default:
			break;
		}
	}
	@Override
	public void focusGained(FocusEvent evento) 
	{
		((JTextField) evento.getComponent()).setText("");
	}

	@Override
	public void focusLost(FocusEvent evento) 
	{
		// TODO Auto-generated method stub
		
	}

}
