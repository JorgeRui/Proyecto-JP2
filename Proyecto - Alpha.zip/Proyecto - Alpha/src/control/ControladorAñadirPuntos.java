/**
 * Implementa FocusListener y ActionListener, controla los botones de la ventana añadir puntos
 */
package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JTextField;

import view.VentanaAñadirPuntosContinuacion;
/**
 * Clase que se encarga de la ventana que añade puntos, contiene el controlador de los distintos componentes
 * @author Jorge Da Silva
 * @version 10.0
 */
public class ControladorAñadirPuntos implements FocusListener, ActionListener 
{
	/**
	 * Controla lo que ocurre cuando en la ventana para añadir puntos pulsas "Ok" o "Cancelar"
	 */
	@Override
	public void actionPerformed(ActionEvent evento)
	{
		switch (evento.getActionCommand()) {
		case "OK":
			Launcher.getCpi().getVentanaAñadirPuntos().setVisible(false);
			VentanaAñadirPuntosContinuacion ventanaAñadirPuntos = new VentanaAñadirPuntosContinuacion(Integer.valueOf(Launcher.getCpi().getVentanaAñadirPuntos().getNumeroPuntosTF().getText()));
			ventanaAñadirPuntos.crearVentana();
			ventanaAñadirPuntos.asignarControlador(Launcher.getCgp());
			ventanaAñadirPuntos.añadirListeners();
			Launcher.getCgp().asignarVentanas(Launcher.getCpi().getVentanaAñadirPuntos(), ventanaAñadirPuntos);
			
			Launcher.getVentana().getContentPane().add(ventanaAñadirPuntos);
			break;
		case "CANCELAR":
			Launcher.getCpi().getVentanaAñadirPuntos().setVisible(false);
			break;
		default:
			break;
		}
	}
	@Override
	public void focusGained(FocusEvent evento) 
	{
		((JTextField) evento.getComponent()).setText("");
	}

	@Override
	public void focusLost(FocusEvent evento) 
	{
	
	}

}

