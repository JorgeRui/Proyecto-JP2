package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.awt.event.FocusEvent;
import java.awt.event.FocusListener;

import javax.swing.JTextField;

import view.VentanaAñadirPuntosContinuacion;

public class ControladorAñadirPuntos implements FocusListener, ActionListener 
{

	
	@Override
	public void actionPerformed(ActionEvent evento)
	{
		switch (evento.getActionCommand()) {
		case "OK":
			Launcher.getCpi().getVentanaAñadirPuntos().setVisible(false);
			//TODO CREAR LA VENTANA NUEVA PARA AÑADIR LOS NUEVOS PUNTOS Y PODER GUARDARLOS
			VentanaAñadirPuntosContinuacion ventanaAñadirPuntos = new VentanaAñadirPuntosContinuacion(Integer.valueOf(Launcher.getCpi().getVentanaAñadirPuntos().getNumeroPuntosTF().getText()));
			ventanaAñadirPuntos.crearVentana();
			Launcher.getVentana().getContentPane().add(ventanaAñadirPuntos);
			System.out.println("TODO OK");
			break;
		case "CANCELAR":
			Launcher.getCpi().getVentanaAñadirPuntos().setVisible(false);
			break;
		default:
			break;
		}
	}
	@Override
	public void focusGained(FocusEvent evento) 
	{
		((JTextField) evento.getComponent()).setText("");
	}

	@Override
	public void focusLost(FocusEvent evento) 
	{
	
	}

}
