package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;
import java.util.Vector;

import model.Punto;
import view.VentanaAñadirPuntos;
import view.VentanaAñadirPuntosContinuacion;

public class ControladorGuardarPuntos implements ActionListener
{
	String nombre, autor, ejeX, ejeY;
	Vector<Punto> puntos;
	VentanaAñadirPuntos ventanaAñadirPuntos;
	VentanaAñadirPuntosContinuacion ventanaAñadirPuntosContinuacion;
	int numPuntos;
	
	public void guardarPuntos()
	{
		puntos		= new Vector<Punto>();
		Punto puntoAux;
		String linea;
		String[] partesLinea;
		for (int i = 0; i < Integer.valueOf(Launcher.getCpi().getVentanaAñadirPuntos().getNumeroPuntosTF().getText()); i++)
		{
			linea = ventanaAñadirPuntosContinuacion.puntosTF[i].getText();
			partesLinea = linea.split(";");
			puntoAux = new Punto(Double.valueOf(partesLinea[0]), Double.valueOf(partesLinea[1]));
			puntos.add(puntoAux);
		}

	}
	@Override
	public void actionPerformed(ActionEvent e)
	{
		guardarPuntos();
		
		nombre 		= ventanaAñadirPuntos.getTituloTF().getText();
		autor  		= ventanaAñadirPuntos.getAutorTF().getText();
		ejeX   		= ventanaAñadirPuntos.getEjeXTF().getText();
		ejeY  		= ventanaAñadirPuntos.getEjeYTF().getText();
		numPuntos	= Integer.valueOf(ventanaAñadirPuntos.getNumeroPuntosTF().getText());
		Archivo.guardarArchivo(nombre, autor, ejeX, ejeY, numPuntos, puntos);		
		ventanaAñadirPuntosContinuacion.setVisible(false);
	}
	public void asignarVentanas(VentanaAñadirPuntos ventanaAñadirPuntos, VentanaAñadirPuntosContinuacion ventanaAñadirPuntosContinuacion )
	{
		this.ventanaAñadirPuntos = ventanaAñadirPuntos;
		this.ventanaAñadirPuntosContinuacion = ventanaAñadirPuntosContinuacion;
	}
}
