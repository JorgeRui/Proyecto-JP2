package control;

import java.io.BufferedWriter;
import java.io.File;
import java.io.FileReader;
import java.io.FileWriter;
import java.text.SimpleDateFormat;
import java.util.Calendar;
import java.util.Scanner;
import java.util.Vector;

import javax.swing.JTextArea;

import model.Punto;

public class Archivo
{
    static File fichero;

    public Archivo()
    {
    }
	public File getFichero() 
	{
		return fichero;
	}

	public void setFichero(File fichero) 
	{
		Archivo.fichero = fichero;
	}

	public static Vector<Punto> LeerArchivo()
	{
		try(Scanner sc = new Scanner(new FileReader(fichero)))
		{
			Vector<Punto> puntos = new Vector<Punto>();
			String nombre, autor, ejeX, ejeY;
			int numPuntos;
			double valorX, valorY;

			String primeraLinea = sc.nextLine();
			String[] partesPrimeraLinea = primeraLinea.split("#");
			nombre 		= partesPrimeraLinea[0];
			autor 		= partesPrimeraLinea[1];
			ejeX   		= partesPrimeraLinea[2];
			ejeY		= partesPrimeraLinea[3];
			numPuntos	= Integer.valueOf(partesPrimeraLinea[4]);

			for (int i = 0; i < numPuntos; i++)
			{
				String linea = sc.nextLine();
				String[] partesLinea = linea.split(";");
				valorX = Double.valueOf(partesLinea[0]);
				valorY = Double.valueOf(partesLinea[1]);

				Punto punto = new Punto(valorX, valorY);
				puntos.addElement(punto);
			}
			System.out.println("Puntos creados a partir de archivo");
			System.out.println("El nombre del archivo es: " + nombre + " y su autor es: " + autor);
			System.out.println("El ejeX es: " + ejeX + " y el ejeY es " + ejeY);
			System.out.println("Numero de puntos: " + puntos.size());
			for (int i = 0; i < puntos.size(); i++) 
			{
				System.out.println("Punto:" + (i+1) + puntos.get(i).toString());
			}
			System.out.println("");
			return puntos;

		} catch (Exception error)
		{
			System.err.println("Error en clase archivo - metodo leerArchivo()");
			System.err.println(error.getMessage());
			return null;		

		}
	}
	public static void guardarLog(JTextArea textArea)
	{
        String hora = new SimpleDateFormat("yyyyMMdd_HHmmss").format(Calendar.getInstance().getTime());
		File archivoAGuardar = new File("Log + " + hora);
		try(BufferedWriter writer = new BufferedWriter(new FileWriter(archivoAGuardar));)
		{

			writer.write(textArea.getText());
		} catch (Exception error)
		{
			System.err.println("Error en clase Archivo - guardarLog");
		}
	}

}
