/**
 * Clase que se encarga de controlar los eventos del {@code JColorChooser}
 * 
 */
package control;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.PaintPanel;

public class ControladorColorChooser implements ActionListener
{
	
	/**
	 * Se encarga de colorear las graficas en función del color que se elija
	 */
	@Override
	public void actionPerformed(ActionEvent evento) 
	{
		PaintPanel pp;

	try 
		{
		//Coge el color seleccionado en el ColorChosser
			Color color = Launcher.getCg().getColorChooser().getColor();
			pp = Launcher.getVentanaG().getPaintPanel();
			//Setea el color de la grafica en el paintPanel
			pp.setColorGrafica(color);
			pp.repaint();
			
		} catch (Exception error)
		{
			System.out.println("Error en clase ControladorColorChooser");
			System.out.println(error.getMessage());
		}

	}
}