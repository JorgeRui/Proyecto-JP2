package control;

import java.awt.Color;
import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.PaintPanel;
/**
 * Clase que se encarga de controlar los eventos del {@code JColorChooser}
 * podriamos colocar esta clase en controlador grafica realmente
 */
public class ControladorColorChooser implements ActionListener
{
	
	/**
	 * Metodo que se encarga de colorear las graficas en funci�n del color que se elija
	 */
	@Override
	public void actionPerformed(ActionEvent evento) 
	{
		PaintPanel pp;

		try 
		{
			Color color = Launcher.getCpg().getColorChooser().getColor();
			pp = Launcher.getVentanaG().getPaintPanel();
			pp.setColorGrafica(color);
			pp.repaint();
			
		} catch (Exception error)
		{
			System.out.println("Error en clase ControladorColorChooser");
			System.out.println(error.getMessage());
		}

	}
}