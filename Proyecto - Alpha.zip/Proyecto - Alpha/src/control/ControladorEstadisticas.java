/**
 * Calcula las distintas estadisticas del programa
 */
package control;

import java.text.DecimalFormat;
import java.util.Vector;

import model.Punto;
import view.VentanaEstadisticas;

public class ControladorEstadisticas 
{
	DecimalFormat formateador = new DecimalFormat("####.####");
	private Double sumaX, sumaY, media, varianza, desviacionMedia, desviacionTipica;
	
	private Double covarianza;
	private Double totalArribaVarianza;
	private Double lineaRegresion;
	
	private VentanaEstadisticas venEstadistica;
	/**
	 * Se encarga de calcular las estadisticas de la X
	 * @param valores
	 */
	public void calcularX(Vector<Double> valores)
	{
		String resultado = String.valueOf(formateador.format(calcularMedia(valores)));
		venEstadistica.getMediaX().setText(resultado);
		resultado	= String.valueOf(formateador.format(calcularVarianza(valores)));
		venEstadistica.getVarianzaX().setText(resultado);
		
		resultado 	= String.valueOf(calcularDesviacionMedia(valores));
		venEstadistica.getDesviacionMediaX().setText(resultado);
		
		resultado 	= String.valueOf(formateador.format(calcularDesviacionTipica(valores)));
		venEstadistica.getDesviacionTipicaX().setText(resultado);
		
		resultado	= String.valueOf(formateador.format(calcularModa(valores)));
		if (Double.valueOf(resultado) == 0)
		{
			venEstadistica.getModaX().setText("No hay moda");
		}
		else
		{
			venEstadistica.getModaX().setText(resultado);	
		}
		
		
	}
	/**
	 * Se encarga de calcular las estadisticas de la Y
	 * @param valores
	 */
	public void calcularY(Vector<Double> valores)
	{
		String resultado = String.valueOf(formateador.format(calcularMedia(valores)));
		venEstadistica.getMediaY().setText(resultado);
		resultado	= String.valueOf(formateador.format(calcularVarianza(valores)));
		venEstadistica.getVarianzaY().setText(resultado);
		
		resultado 	= String.valueOf(calcularDesviacionMedia(valores));
		venEstadistica.getDesviacionMediaY().setText(resultado);
		
		resultado 	= String.valueOf(formateador.format(calcularDesviacionTipica(valores)));
		venEstadistica.getDesviacionTipicaY().setText(resultado);
		
		resultado	= String.valueOf(formateador.format(calcularModa(valores)));
		if (Double.valueOf(resultado) == 0)
		{
			venEstadistica.getModaY().setText("No hay moda");
		}
		else
		{
			venEstadistica.getModaY().setText(resultado);
		}
		
		
	}
	/**
	 * Se encarga de calcular la correlacion
	 */
	public void calcularCorrelacion()
	{
		String resultado;
		Double resultadoFormat;
		resultado = String.valueOf(Launcher.getCe().calcularCovarianza(Launcher.getCg().sacarX(Launcher.getCpi().getPuntos()), Launcher.getCg().sacarY(Launcher.getCpi().getPuntos())) /(Launcher.getCe().calcularDesviacionTipica(Launcher.getCg().sacarX(Launcher.getCpi().getPuntos())) * Launcher.getCe().calcularDesviacionTipica(Launcher.getCg().sacarY(Launcher.getCpi().getPuntos()))));
		resultadoFormat = Double.valueOf(resultado);
		venEstadistica.getCoeficienteCorrelacion().setText(formateador.format(resultadoFormat));
	}
	
	/**
	 * Se encarga de calcular la media de todos los valores
	 * @param valores el vector de Double
	 * @return media Double
	 */
	public Double calcularMedia(Vector<Double> valores){
		sumaX = 0D;
		media = 0D;
		for (int i=0; i< valores.size(); i++){
			sumaX += valores.elementAt(i);
		}
		media = (sumaX/valores.size());
		return media;
		
	}
	/**
	 * Se encarga de calcular la varianza de los valores
	 * @param valores el vector de Double
	 * @return varianza Double
	 */
	public Double calcularVarianza(Vector<Double> valores){
		varianza = 0.0;
		totalArribaVarianza= 0.0;
		
		for (int i=0; i< valores.size(); i++)
		{
			totalArribaVarianza += (valores.get(i)-media)*(valores.get(i)-media);
		}
		varianza = totalArribaVarianza/valores.size();
		
		return varianza;
		
	}
	/**
	 * Se encarga de calcular la covarianza de los valores (producto de x * y - mediax - mediay)
	 * @param valoresX el vector de Double
	 * @param valoresY el vector de Double
	 * @return
	 */
	
	public double calcularCovarianza(Vector<Double> valoresX ,Vector<Double> valoresY){
		covarianza = 0D;
		double mediaX, mediaY;
		double sumaXporY = 0D;
		mediaX = calcularMedia(valoresX);
		mediaY = calcularMedia(valoresY);
		for (int i=0; i< valoresY.size(); i++)
		{
			sumaXporY += valoresX.elementAt(i) * valoresY.elementAt(i);
		}
		covarianza = sumaXporY / valoresX.size() - mediaX * mediaY;
		
		return covarianza;
	}
	
	
	/**
	 * Se encarga de calcular la desviacion media de los valores
	 * @param valoresX el vector de Double
	 * @return desviacionMedia Double 
	 */
	public Double calcularDesviacionMedia(Vector<Double> valores){
		desviacionMedia = 0.0;
		Double totalArribaDesviacionMedia= 0.0;
		for (int i=0; i< valores.size(); i++){
			totalArribaDesviacionMedia += (valores.get(i)-media);
		}
		desviacionMedia = totalArribaDesviacionMedia/valores.size();
		
		return desviacionMedia;
		
	}
	/**
	 * Se encarga de calcular la desviacion tipica
	 * @param valoresX el vector de Double
	 * @return desviacionTipica Double
	 */
	public Double calcularDesviacionTipica(Vector<Double> valores){
		
		desviacionTipica= Math.sqrt(totalArribaVarianza/media);
		
		return desviacionTipica;
		
	}
	/**
	 * Se encarga de calcular la moda
	 * @param valoresX el vector de double
	 * @return moda Double
	 */

	public Double calcularModa(Vector<Double> valores) {
		Double moda = null;
		int maximaVecesRepite = 0;
		for(int i=0; i<valores.size(); i++)
		{
			int vecesRepite = 0;
			for(int j=0; j<valores.size(); j++)
			{
				if(valores.elementAt(i) == valores.elementAt(j))
					vecesRepite++;
			}
			if(vecesRepite > maximaVecesRepite){
				moda = valores.elementAt(i);
				maximaVecesRepite = vecesRepite;
			}
		}
		
		if (moda == null)
		{
			return 0D;
		}
		return moda;
	}
	
	/**
	 * Calcula la linea de Regresion
	 * @param valoresX el Vector<Double>
	 * @param valoresY el Vector<Double>
	 * @return lineaRegresion el Vector<Double>
	 */
	public Vector<Punto> calcularLineaRegresion(Vector<Double> valoresX, Vector<Double> valoresY){
		double mediaX, mediaY, covarianza, varianzaX;
		double y, a , m;
		
		Vector<Punto> lineaRegresion = new Vector<Punto>();
		mediaX = calcularMedia(valoresX);
		mediaY = calcularMedia(valoresY);
		covarianza = calcularCovarianza(valoresX, valoresY);
		varianzaX = calcularVarianza(valoresX);

		
		m =covarianza/varianzaX;
		a = mediaY - (m*mediaX);
	
		for (int x = 0; x < 100; x++) 
		{
			Punto puntoAux;
			y = m*x + a;
			puntoAux = new Punto(x,y);
			lineaRegresion.add(puntoAux);
		}
		
		
		return lineaRegresion;
	}
	//
	/**
	 * Si es par, ordena los valores y coge el del medio, si es impar, coge los dos valores próximos al medio sumalos y divide entre dos
	 * @param valores
	 * @return
	 */
	public Double calcularMediana(Vector<Double> valores) 
	{
		//NO HEMOS SIDO CAPAZ
		Double mediana = null;
		@SuppressWarnings("unused")
		boolean esPar = false;
		if (valores.size() % 2 == 0)
		{
			esPar = true;
		}

		for (int i = 0; i < valores.size(); i++)
		{
			
		}

		return mediana;
		
	}
	/**
	 * Añade la ventana estadisticas
	 * @param venEstadisticas la VentanaEstadisticas
	 */
	public void añadirVentana(VentanaEstadisticas venEstadisticas)
	{
		this.venEstadistica = venEstadisticas;
	}
		
	
}
