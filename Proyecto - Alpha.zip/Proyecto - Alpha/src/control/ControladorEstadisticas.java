package control;

import java.util.Vector;

public class ControladorEstadisticas {
	private Double suma;
	private Double media;
	private Double varianza;
	private Double desviacionMedia;
	private Double totalArribaVarianza;
	private Double desviacionTipica;
	
	
	public void resolver(Vector<Double> valores, String nombre){
		switch(nombre){
		case "media": 	calcularMedia(valores);
							break;
		}
		switch(nombre){
		case "varianza": 	calcularVarianza(valores);
							break;
		}
		switch(nombre){
		case "desviacion media": 	calcularDesviacionMedia(valores);
							break;
		}
		switch(nombre){
		case "desviacion tipica": 	calcularDesviacionTipica(valores);
							break;
		}
		
	}
	
	/**
	 * Se encarga de calcular la media de todos los valores
	 * @param valores el vector de Double
	 * @return media Double
	 */
	public Double calcularMedia(Vector<Double> valores){
		suma = null;
		media = null;
		for (int i=0; i<= valores.size(); i++){
			suma += valores.elementAt(i);
		}
		media = (suma/valores.size());
		
		return media;
		
	}
	/**
	 * Se encarga de calcular la varianza de los valores
	 * @param valores el vector de Double
	 * @return varianza Double
	 */
	public Double calcularVarianza(Vector<Double> valores){
		varianza = 0.0;
		totalArribaVarianza= 0.0;
		for (int i=0; i<= valores.size(); i++){
			totalArribaVarianza += (valores.get(i)-media)*(valores.get(i)-media);
		}
		varianza = totalArribaVarianza/valores.size();
		
		return varianza;
		
	}
	/**
	 * Se encarga de calcular la desviacion media de los valores
	 * @param valores el vector de Double
	 * @return desviacionMedia Double 
	 */
	public Double calcularDesviacionMedia(Vector<Double> valores){
		desviacionMedia = 0.0;
		Double totalArribaDesviacionMedia= 0.0;
		for (int i=0; i<= valores.size(); i++){
			totalArribaDesviacionMedia += (valores.get(i)-media);
		}
		desviacionMedia = totalArribaDesviacionMedia/valores.size();
		
		return desviacionMedia;
		
	}
	/**
	 * Se encarga de calcular la desviacion tipica
	 * @param valores el vector de Double
	 * @return desviacionTipica Double
	 */
	public Double calcularDesviacionTipica(Vector<Double> valores){
		
		desviacionTipica= Math.sqrt(totalArribaVarianza/media);
		
		return desviacionTipica;
		
	}
	

	public Double calcularModa(Vector<Double> valores) {
		Double moda = null;
		int maximaVecesRepite = 0;
		

		for(int i=0; i<valores.size(); i++){
		int vecesRepite = 0;
		for(int j=0; j<valores.size(); j++){
		if(valores.elementAt(i) == valores.elementAt(j))
		vecesRepite++;
		}
		if(vecesRepite > maximaVecesRepite){
		moda = valores.elementAt(i);
		maximaVecesRepite = vecesRepite;
		}
		}

	
        return moda;
	}
	

	public Double calcularMediana(Vector<Double> valores) {
		//NO HEMOS SIDO CAPAZ
		Double mediana = null;
//		int i, j;
//		Double aux;
//	      int a[] = new int[5];
//	     
//	      for(i = 1; i < valores.size(); i++){
//	        for(j = 0; j < valores.size() - i; j++){
//	          if(valores.elementAt(j) > valores.elementAt(j+1)){
//	            aux = valores.elementAt(j);
//	            a[j] = a[j + 1];
//	            aux = valores.elementAt(j+1);
//	            
//	          }    
//	        } 
//	      }
//	      System.out.printf("La mediana es: %d\n",a[2]);
//
		return mediana;
		
	}
		
	

	 

	
	
	
}
