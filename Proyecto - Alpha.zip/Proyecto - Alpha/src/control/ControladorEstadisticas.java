package control;

import java.text.DecimalFormat;
import java.util.Vector;

import view.VentanaEstadisticas;

public class ControladorEstadisticas 
{
	DecimalFormat formateador = new DecimalFormat("####.####");
	private Double sumaX, sumaY, media, varianza, desviacionMedia, desviacionTipica;
	
	private Double covarianza;
	private Double totalArribaVarianza;
	private Double lineaRegresion;
	
	private VentanaEstadisticas venEstadistica;
	
	public void calcularX(Vector<Double> valores)
	{
		String resultado = String.valueOf(formateador.format(calcularMedia(valores)));
		venEstadistica.getMediaX().setText(resultado);
		resultado	= String.valueOf(formateador.format(calcularVarianza(valores)));
		venEstadistica.getVarianzaX().setText(resultado);
		
		resultado 	= String.valueOf(calcularDesviacionMedia(valores));
		venEstadistica.getDesviacionMediaX().setText(resultado);
		
		resultado 	= String.valueOf(formateador.format(calcularDesviacionTipica(valores)));
		venEstadistica.getDesviacionTipicaX().setText(resultado);
		
		resultado	= String.valueOf(formateador.format(calcularModa(valores)));
		if (Double.valueOf(resultado) == 0)
		{
			venEstadistica.getModaX().setText("No hay moda");
		}
		else
		{
			venEstadistica.getModaX().setText(resultado);	
		}
		
		
	}
	
	public void calcularY(Vector<Double> valores)
	{
		String resultado = String.valueOf(formateador.format(calcularMedia(valores)));
		venEstadistica.getMediaY().setText(resultado);
		resultado	= String.valueOf(formateador.format(calcularVarianza(valores)));
		venEstadistica.getVarianzaY().setText(resultado);
		
		resultado 	= String.valueOf(calcularDesviacionMedia(valores));
		venEstadistica.getDesviacionMediaY().setText(resultado);
		
		resultado 	= String.valueOf(formateador.format(calcularDesviacionTipica(valores)));
		venEstadistica.getDesviacionTipicaY().setText(resultado);
		
		resultado	= String.valueOf(formateador.format(calcularModa(valores)));
		if (Double.valueOf(resultado) == 0)
		{
			venEstadistica.getModaY().setText("No hay moda");
		}
		else
		{
			venEstadistica.getModaY().setText(resultado);
		}
		
		
	}
	
	/**
	 * Se encarga de calcular la media de todos los valores
	 * @param valores el vector de Double
	 * @return media Double
	 */
	public Double calcularMedia(Vector<Double> valores){
		sumaX = 0D;
		media = 0D;
		for (int i=0; i< valores.size(); i++){
			sumaX += valores.elementAt(i);
		}
		media = (sumaX/valores.size());
		return media;
		
		
		
	}
	/**
	 * Se encarga de calcular la varianza de los valores
	 * @param valores el vector de Double
	 * @return varianza Double
	 */
	public Double calcularVarianza(Vector<Double> valores){
		varianza = 0.0;
		totalArribaVarianza= 0.0;
		
		for (int i=0; i< valores.size(); i++)
		{
			totalArribaVarianza += (valores.get(i)-media)*(valores.get(i)-media);
		}
		varianza = totalArribaVarianza/valores.size();
		
		return varianza;
		
	}
	/**
	 * Se encarga de calcular la covarianza de los valores
	 * @param valoresX el vector de Double
	 * @param valoresY el vector de Double
	 * @return
	 */
	
	public double calcularCovarianza(Vector<Double> valores,Vector<Double> valoresY){
		covarianza = null;
		
		for (int i=0; i< valoresY.size(); i++){
			sumaY += valoresY.elementAt(i);
		}
		//covarianza = ((sumaX-Math.abs(sumaX))*(sumaY-Math.abs(sumaY))/valores.size());
		
		return covarianza;
	}
	
	
	/**
	 * Se encarga de calcular la desviacion media de los valores
	 * @param valoresX el vector de Double
	 * @return desviacionMedia Double 
	 */
	public Double calcularDesviacionMedia(Vector<Double> valores){
		desviacionMedia = 0.0;
		Double totalArribaDesviacionMedia= 0.0;
		for (int i=0; i< valores.size(); i++){
			totalArribaDesviacionMedia += (valores.get(i)-media);
		}
		desviacionMedia = totalArribaDesviacionMedia/valores.size();
		
		return desviacionMedia;
		
	}
	/**
	 * Se encarga de calcular la desviacion tipica
	 * @param valoresX el vector de Double
	 * @return desviacionTipica Double
	 */
	public Double calcularDesviacionTipica(Vector<Double> valores){
		
		desviacionTipica= Math.sqrt(totalArribaVarianza/media);
		
		return desviacionTipica;
		
	}
	/**
	 * Se encarga de calcular la moda
	 * @param valoresX el vector de double
	 * @return moda Double
	 */

	public Double calcularModa(Vector<Double> valores) {
		Double moda = null;
		int maximaVecesRepite = 0;
		for(int i=0; i<valores.size(); i++)
		{
			int vecesRepite = 0;
			for(int j=0; j<valores.size(); j++)
			{
				if(valores.elementAt(i) == valores.elementAt(j))
					vecesRepite++;
			}
			if(vecesRepite > maximaVecesRepite){
				moda = valores.elementAt(i);
				maximaVecesRepite = vecesRepite;
			}
		}
		
		if (moda == null)
		{
			return 0D;
		}
		return moda;
	}
	
	
	//////////////////////////////////
	public Double calcularLineaRegresion(Vector<Double> valoresX, Vector<Double> valoresY){
		lineaRegresion= null;
		
		
		
		
		return lineaRegresion;
	}
	
	/////////////////////////////////////////////
/**
 * Si es par, ordena los valores y coge el del medio, si es impar, coge los dos valores próximos al medio sumalos y divide entre dos
 * @param valores
 * @return
 */
	public Double calcularMediana(Vector<Double> valores) 
	{
		//NO HEMOS SIDO CAPAZ
		Double mediana = null;
		@SuppressWarnings("unused")
		boolean esPar = false;
		if (valores.size() % 2 == 0)
		{
			esPar = true;
		}

		for (int i = 0; i < valores.size(); i++)
		{
			
		}

		return mediana;
		
	}
	
	public void añadirVentana(VentanaEstadisticas venEstadisticas)
	{
		this.venEstadistica = venEstadisticas;
	}
		
	
}
