package control;

import java.util.Vector;

public class ControladorEstadisticas 
{
	private Double sumaX;
	private Double sumaY;
	private Double media;
	private Double varianza;
	private Double covarianza;
	private Double desviacionMedia;
	private Double totalArribaVarianza;
	private Double desviacionTipica;
	private Double lineaRegresion;
	
	public void resolver(Vector<Double> valoresX, String nombre){
		switch(nombre)
		{
		case "media": 	
			calcularMedia(valoresX);
			break;
		}
		switch(nombre){
		case "varianza":
			calcularVarianza(valoresX);
			break;
		}
		switch(nombre){
		case "desviacion media": 
			calcularDesviacionMedia(valoresX);
			break;
		}
		switch(nombre){
		case "desviacion tipica":
			calcularDesviacionTipica(valoresX);
			break;
		}

	}
	
	/**
	 * Se encarga de calcular la media de todos los valores
	 * @param valoresX el vector de Double
	 * @return media Double
	 */
	public Double calcularMedia(Vector<Double> valoresX){
		sumaX = null;
		media = null;
		for (int i=0; i<= valoresX.size(); i++){
			sumaX += valoresX.elementAt(i);
		}
		media = (sumaX/valoresX.size());
		
		return media;
		
	}
	/**
	 * Se encarga de calcular la varianza de los valores
	 * @param valoresX el vector de Double
	 * @return varianza Double
	 */
	public Double calcularVarianza(Vector<Double> valoresX){
		varianza = 0.0;
		totalArribaVarianza= 0.0;
		for (int i=0; i<= valoresX.size(); i++){
			totalArribaVarianza += (valoresX.get(i)-media)*(valoresX.get(i)-media);
		}
		varianza = totalArribaVarianza/valoresX.size();
		
		return varianza;
		
	}
	/**
	 * Se encarga de calcular la covarianza de los valores
	 * @param valoresX el vector de Double
	 * @param valoresY el vector de Double
	 * @return
	 */
	
	public double calcularCovarianza(Vector<Double> valoresX,Vector<Double> valoresY){
		covarianza = null;
		
		for (int i=0; i<= valoresY.size(); i++){
			sumaY += valoresY.elementAt(i);
		}
		covarianza = ((sumaX-Math.abs(sumaX))*(sumaY-Math.abs(sumaY))/valoresX.size());
		
		return covarianza;
	}
	
	
	/**
	 * Se encarga de calcular la desviacion media de los valores
	 * @param valoresX el vector de Double
	 * @return desviacionMedia Double 
	 */
	public Double calcularDesviacionMedia(Vector<Double> valoresX){
		desviacionMedia = 0.0;
		Double totalArribaDesviacionMedia= 0.0;
		for (int i=0; i<= valoresX.size(); i++){
			totalArribaDesviacionMedia += (valoresX.get(i)-media);
		}
		desviacionMedia = totalArribaDesviacionMedia/valoresX.size();
		
		return desviacionMedia;
		
	}
	/**
	 * Se encarga de calcular la desviacion tipica
	 * @param valoresX el vector de Double
	 * @return desviacionTipica Double
	 */
	public Double calcularDesviacionTipica(Vector<Double> valores){
		
		desviacionTipica= Math.sqrt(totalArribaVarianza/media);
		
		return desviacionTipica;
		
	}
	/**
	 * Se encarga de calcular la moda
	 * @param valoresX el vector de double
	 * @return moda Double
	 */

	public Double calcularModa(Vector<Double> valoresX) {
		Double moda = null;
		int maximaVecesRepite = 0;
		for(int i=0; i<valoresX.size(); i++)
		{
			int vecesRepite = 0;
			for(int j=0; j<valoresX.size(); j++)
			{
				if(valoresX.elementAt(i) == valoresX.elementAt(j))
					vecesRepite++;
			}
			if(vecesRepite > maximaVecesRepite){
				moda = valoresX.elementAt(i);
				maximaVecesRepite = vecesRepite;
			}
		}

		return moda;
	}
	
	
	//////////////////////////////////
	public Double calcularLineaRegresion(Vector<Double> valoresX, Vector<Double> valoresY){
		lineaRegresion= null;
		
		
		
		
		return lineaRegresion;
	}
	
	/////////////////////////////////////////////
/**
 * Si es par, ordena los valores y coge el del medio, si es impar, coge los dos valores próximos al medio sumalos y divide entre dos
 * @param valores
 * @return
 */
	public Double calcularMediana(Vector<Double> valoresX) 
	{
		//NO HEMOS SIDO CAPAZ
		Double mediana = null;
		@SuppressWarnings("unused")
		boolean esPar = false;
		if (valoresX.size() % 2 == 0)
		{
			esPar = true;
		}

		for (int i = 0; i < valoresX.size(); i++)
		{
			
		}

		return mediana;
		
	}
		
	
}
