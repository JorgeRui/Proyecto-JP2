package control;

import java.util.Vector;

public class ControladorEstadisticas 
{
	private Double suma;
	private Double media;
	private Double varianza;
	private Double desviacionMedia;
	private Double totalArribaVarianza;
	private Double desviacionTipica;
	
	
	public void resolver(Vector<Double> valores, String nombre){
		switch(nombre)
		{
		case "media": 	
			calcularMedia(valores);
			break;
		}
		switch(nombre){
		case "varianza":
			calcularVarianza(valores);
			break;
		}
		switch(nombre){
		case "desviacion media": 
			calcularDesviacionMedia(valores);
			break;
		}
		switch(nombre){
		case "desviacion tipica":
			calcularDesviacionTipica(valores);
			break;
		}

	}
	
	/**
	 * Se encarga de calcular la media de todos los valores
	 * @param valores el vector de Double
	 * @return media Double
	 */
	public Double calcularMedia(Vector<Double> valores){
		suma = null;
		media = null;
		for (int i=0; i<= valores.size(); i++){
			suma += valores.elementAt(i);
		}
		media = (suma/valores.size());
		
		return media;
		
	}
	/**
	 * Se encarga de calcular la varianza de los valores
	 * @param valores el vector de Double
	 * @return varianza Double
	 */
	public Double calcularVarianza(Vector<Double> valores){
		varianza = 0.0;
		totalArribaVarianza= 0.0;
		for (int i=0; i<= valores.size(); i++){
			totalArribaVarianza += (valores.get(i)-media)*(valores.get(i)-media);
		}
		varianza = totalArribaVarianza/valores.size();
		
		return varianza;
		
	}
	/**
	 * Se encarga de calcular la desviacion media de los valores
	 * @param valores el vector de Double
	 * @return desviacionMedia Double 
	 */
	public Double calcularDesviacionMedia(Vector<Double> valores){
		desviacionMedia = 0.0;
		Double totalArribaDesviacionMedia= 0.0;
		for (int i=0; i<= valores.size(); i++){
			totalArribaDesviacionMedia += (valores.get(i)-media);
		}
		desviacionMedia = totalArribaDesviacionMedia/valores.size();
		
		return desviacionMedia;
		
	}
	/**
	 * Se encarga de calcular la desviacion tipica
	 * @param valores el vector de Double
	 * @return desviacionTipica Double
	 */
	public Double calcularDesviacionTipica(Vector<Double> valores){
		
		desviacionTipica= Math.sqrt(totalArribaVarianza/media);
		
		return desviacionTipica;
		
	}
	

	public Double calcularModa(Vector<Double> valores) {
		Double moda = null;
		int maximaVecesRepite = 0;
		for(int i=0; i<valores.size(); i++)
		{
			int vecesRepite = 0;
			for(int j=0; j<valores.size(); j++)
			{
				if(valores.elementAt(i) == valores.elementAt(j))
					vecesRepite++;
			}
			if(vecesRepite > maximaVecesRepite){
				moda = valores.elementAt(i);
				maximaVecesRepite = vecesRepite;
			}
		}

		return moda;
	}

/**
 * Si es par, ordena los valores y coge el del medio, si es impar, coge los dos valores próximos al medio sumalos y divide entre dos
 * @param valores
 * @return
 */
	public Double calcularMediana(Vector<Double> valores) 
	{
		//NO HEMOS SIDO CAPAZ
		Double mediana = null;
		@SuppressWarnings("unused")
		boolean esPar = false;
		if (valores.size() % 2 == 0)
		{
			esPar = true;
		}

		for (int i = 0; i < valores.size(); i++)
		{
			
		}

		return mediana;
		
	}
		
	

	 

	
	
	
}
