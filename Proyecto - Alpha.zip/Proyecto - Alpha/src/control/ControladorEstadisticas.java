package control;

import java.text.DecimalFormat;
import java.util.Vector;

import javax.swing.JOptionPane;

import model.Punto;
import view.VentanaEstadisticas;

public class ControladorEstadisticas 
{
	DecimalFormat formateador = new DecimalFormat("####.####");	
	public VentanaEstadisticas venEstadistica;
	
	public void calcularX(Vector<Double> valores)
	{
		try
		{
			String resultado = String.valueOf(formateador.format(calcularMedia(valores)));
			venEstadistica.getMediaX().setText(resultado);
			resultado	= String.valueOf(formateador.format(calcularVarianza(valores)));
			venEstadistica.getVarianzaX().setText(resultado);
			
			resultado 	= String.valueOf(formateador.format(calcularDesviacionMedia(valores)));
			venEstadistica.getDesviacionMediaX().setText(resultado);
			
			resultado 	= String.valueOf(formateador.format(calcularDesviacionTipica(valores)));
			venEstadistica.getDesviacionTipicaX().setText(resultado);
			
		} catch (Exception error)
		{
			JOptionPane.showMessageDialog(Launcher.getVentana().getContentPane(),"Error en clase ControladorEstadisticas", "Error en clase ControladorEstadisticas",JOptionPane.ERROR_MESSAGE);
		}
			
		
	}
	
	public void calcularY(Vector<Double> valores)
	{
		try 
		{
			String resultado = String.valueOf(formateador.format(calcularMedia(valores)));
			venEstadistica.getMediaY().setText(resultado);
			resultado	= String.valueOf(formateador.format(calcularVarianza(valores)));
			venEstadistica.getVarianzaY().setText(resultado);
			
			resultado 	= String.valueOf(formateador.format(calcularDesviacionMedia(valores)));
			venEstadistica.getDesviacionMediaY().setText(resultado);
			
			resultado 	= String.valueOf(formateador.format(calcularDesviacionTipica(valores)));
			venEstadistica.getDesviacionTipicaY().setText(resultado);
			
		} catch (Exception error) 
		{
			JOptionPane.showMessageDialog(Launcher.getVentana().getContentPane(),"Error en clase ControladorEstadisticas", "Error en clase ControladorEstadisticas",JOptionPane.ERROR_MESSAGE);
		}
				
	}
	public void calcularCorrelacion()
	{
		String resultado;
		Double resultadoFormat;
		resultado = String.valueOf(Launcher.getCe().calcularCovarianza(Launcher.getCg().sacarX(Launcher.getCpi().getPuntos()), Launcher.getCg().sacarY(Launcher.getCpi().getPuntos())) /(Launcher.getCe().calcularDesviacionTipica(Launcher.getCg().sacarX(Launcher.getCpi().getPuntos())) * Launcher.getCe().calcularDesviacionTipica(Launcher.getCg().sacarY(Launcher.getCpi().getPuntos()))));
		resultadoFormat = Double.valueOf(resultado);
		System.out.println("Correlacion: " + resultadoFormat);
		venEstadistica.getCoeficienteCorrelacion().setText(formateador.format(resultadoFormat));
	}
	
	/**
	 * Se encarga de calcular la media de todos los valores
	 * @param valores el vector de Double
	 * @return media Double
	 */
	public Double calcularMedia(Vector<Double> valores){

		double media = 0D, suma = 0D;
		for (int i=0; i < valores.size(); i++)
		{
			suma += valores.elementAt(i);
		}
		media = (suma/valores.size());
		return media;
		
	}
	/**
	 * Se encarga de calcular la varianza de los valores
	 * @param valores el vector de Double
	 * @return varianza Double
	 */
	public Double calcularVarianza(Vector<Double> valores){
		double varianza = 0D;
		double media = Math.pow(calcularMedia(valores),2);
		double sumaX2 = 0D;
		
		for (int i = 0; i < valores.size(); i++)
		{
			sumaX2 += Math.pow(valores.get(i), 2);

		}
		varianza = ( sumaX2 / valores.size() ) - media;
		return varianza;
		
	}
	/**
	 * Se encarga de calcular la covarianza de los valores (producto de x * y - mediax - mediay)
	 * @param valoresX el vector de Double
	 * @param valoresY el vector de Double
	 * @return
	 */
	
	public double calcularCovarianza(Vector<Double> valoresX ,Vector<Double> valoresY){
		double covarianza = 0D;
		double mediaX, mediaY;
		double sumaXporY = 0D;
		mediaX = calcularMedia(valoresX);
		mediaY = calcularMedia(valoresY);
		for (int i=0; i< valoresY.size(); i++)
		{
			sumaXporY += valoresX.elementAt(i) * valoresY.elementAt(i);
		}
		covarianza = sumaXporY / valoresX.size() - mediaX * mediaY;
		
		return covarianza;
	}
	
	
	/**
	 * Se encarga de calcular la desviacion media de los valores
	 * @param valoresX el vector de Double
	 * @return desviacionMedia Double 
	 */
	public Double calcularDesviacionMedia(Vector<Double> valores){
		double desviacionMedia = 0.0;
		double mediaX = calcularMedia(valores);
		for (int i=0; i< valores.size(); i++){
			desviacionMedia += Math.abs(valores.get(i) - mediaX);
		}

		desviacionMedia = desviacionMedia/valores.size();
		return desviacionMedia;
		
	}
	/**
	 * Se encarga de calcular la desviacion tipica
	 * @param valoresX el vector de Double
	 * @return desviacionTipica Double
	 */
	public Double calcularDesviacionTipica(Vector<Double> valores){
		
		double desviacionTipica = 0D;
		desviacionTipica= Math.sqrt(calcularVarianza(valores));
		
		return desviacionTipica;
		
	}

	public Vector<Punto> calcularLineaRegresion(Vector<Punto> puntos)
	{
		double mediaX, mediaY, covarianza, varianzaX;
		double y, a , m;
		Vector<Double> valoresX, valoresY;
		valoresX = new Vector<Double>();
		valoresY = new Vector<Double>();
		
		for (int i = 0; i < puntos.size(); i++)
		{
			valoresX.add(puntos.get(i).getX());
			valoresY.add(puntos.get(i).getY());
		}
		
		Vector<Punto> lineaRegresion = new Vector<Punto>();
		mediaX = calcularMedia(valoresX);
		mediaY = calcularMedia(valoresY);
		covarianza = calcularCovarianza(valoresX, valoresY);
		varianzaX = calcularVarianza(valoresX);

		
		m = covarianza/varianzaX;
		a = mediaY - (m*mediaX);
	
		for (int x = -puntos.size() - 100000; x <= puntos.size() + 100000; x++) 
		{
			Punto puntoAux;
			y = m*x + a;
			puntoAux = new Punto(x,y);
			lineaRegresion.add(puntoAux);
		}
		
		return lineaRegresion;
	}
	public void añadirVentana(VentanaEstadisticas venEstadisticas)
	{
		this.venEstadistica = venEstadisticas;
	}
		
	
}
