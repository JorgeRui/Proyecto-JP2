package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.VentanaAyuda;

public class ControladorAyuda implements ActionListener
{

	VentanaAyuda ventana;
	public void asignarVentana(VentanaAyuda ventana)
	{
		this.ventana = ventana;
	}
	@Override
	public void actionPerformed(ActionEvent evento)
	{
		switch (evento.getActionCommand())
		{
		case "GUARDARLOGAC":
			Archivo.guardarLog(VentanaAyuda.getTextAreaLog());
			break;
		case "ENVIARLOGAC":
			
			break;
			
		default:
			System.out.println("Error, comando no reconocido");
			break;
		}
	}

}
