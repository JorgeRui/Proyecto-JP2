package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import view.VentanaLog;

public class ControladorAyuda implements ActionListener
{

	VentanaLog ventana;
	public void asignarVentana(VentanaLog ventana)
	{
		this.ventana = ventana;
	}
	@Override
	public void actionPerformed(ActionEvent evento)
	{
		switch (evento.getActionCommand())
		{
		case "GUARDARLOGAC":
			Archivo.guardarLog(VentanaLog.getTextAreaLog());
			break;
		case "ENVIARLOGAC":
			
			break;
			
		default:
			System.out.println("Error, comando no reconocido");
			break;
		}
	}

}
