package control;

import java.awt.event.ActionEvent;
import java.awt.event.ActionListener;

import javax.swing.JOptionPane;

import view.VentanaLog;

public class ControladorAyuda implements ActionListener
{

	VentanaLog ventana;
	public void asignarVentana(VentanaLog ventana)
	{
		this.ventana = ventana;
	}
	@Override
	public void actionPerformed(ActionEvent evento)
	{
		switch (evento.getActionCommand())
		{
		case "GUARDARLOGAC":
			Archivo.guardarLog(VentanaLog.getTextAreaLog());
			break;
		case "ENVIARLOGAC":
			Launcher.getVentanaLog().añadirLog("Se ha intentado enviar un email - función no implementada");
			JOptionPane.showMessageDialog(Launcher.getVentana().getContentPane(),"Función no implementada", "Función no implementada",JOptionPane.WARNING_MESSAGE);
			break;
			
		default:
			System.out.println("Error, comando no reconocido");
			break;
		}
	}

}
