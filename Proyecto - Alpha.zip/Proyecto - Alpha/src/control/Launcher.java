package control;

import view.VentanaGrafica;
import view.VentanaLog;
import view.VentanaPrincipal;

public class Launcher 
{
	static ControladorPrincipal cpi;
	static ControladorAñadirPuntos cap;
	static ControladorGrafica cg;
	static ControladorColorChooser ccc;
	static ControladorAyuda			ca;
	static ControladorEstadisticas ce;
	static ControladorGuardarPuntos cgp;
	
	/**
	 * Metodo que permite acceder al controlador principal
	 * @return cpi
	 */ 
	
	public static ControladorPrincipal getCpi() {
		return cpi;
	}
	/**
	 * Metodo que permite acceder al controlador de añadir puntos
	 * @return cap
	 */
	
	public static ControladorAñadirPuntos getCap() {
		return cap;
	}
	/**
	 * Metodo que permite acceder al controlador de grafica
	 * @return cg
	 */
	
	public static ControladorGrafica getCg()
	{
		return cg;
	}
	
	/**
	 * Metodo que permite acceder al controlador ayuda
	 * @return ca
	 */
	
	public static ControladorAyuda getCa() {
		return ca;
	}
	
	/**
	 * Metodo que permite acceder al controlador de estadisticas
	 * @return ce
	 */
	
	public static ControladorEstadisticas getCe() {
		return ce;
	}
	
	/**
	 * Metodo que permite acceder al controlador de guardar los puntos
	 * @return cgp
	 */
	
	public static ControladorGuardarPuntos getCgp() {
		return cgp;
	}
	
	static VentanaPrincipal ventana;
	static VentanaGrafica ventanaG;
	static VentanaLog	  ventanaLog;
	
	/**
	 * Metodo que permite acceder a la ventana principal
	 * @return ventana
	 */
	
	public static VentanaPrincipal getVentana()
	{
		return ventana;
	}

	/**
	 * Metodo que permite acceder a la ventana grafica
	 * @return
	 */
	
	
	public static VentanaGrafica getVentanaG()
	{
		return ventanaG;
	}
	
	/**
	 * Metodo que permite acceder a la ventana Log
	 * @return ventanaLog
	 */
	
	public static VentanaLog getVentanaLog()
	{
		return ventanaLog;
	}
	
	/**
	 * Metodo main donde declaro las ventanas y los controladores
	 * @param args
	 */
	
	public static void main(String[] args) 
	{
		cpi						 = new ControladorPrincipal();
		cap						 = new ControladorAñadirPuntos();
		ccc						 = new ControladorColorChooser();
		cg						 = new ControladorGrafica(ccc);
		ca						 = new ControladorAyuda();
		ce						 = new ControladorEstadisticas();
		cgp						 = new ControladorGuardarPuntos();
		
		ventana		 = new VentanaPrincipal(cpi);
		ventanaG	 = new VentanaGrafica(cg);
		ventanaLog	 = new VentanaLog();

		cg.asignarVentana(ventanaG);
		cpi.asignarVentana(ventana);
		ca.asignarVentana(ventanaLog);
		
		ventana.getContentPane().add(ventanaLog);
		ventana.añadirVentanaGrafica(ventanaG);
		
		ventana.setVisible(true);	
	}

}
