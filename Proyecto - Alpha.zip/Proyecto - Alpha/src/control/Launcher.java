package control;

import view.VentanaPrincipal;

public class Launcher {
	static ControladorPrincipal cpi;
	static ControladorAñadirPuntos cap;

	public static ControladorPrincipal getCpi() {
		return cpi;
	}

	public static ControladorAñadirPuntos getCap() {
		return cap;
	}

	public static void main(String[] args) 
	{
		cpi						 = new ControladorPrincipal();
		cap						 = new ControladorAñadirPuntos();
		VentanaPrincipal ventana = new VentanaPrincipal(cpi);
		cpi.asignarVentana(ventana);
		ventana.setVisible(true);	
	}

}
