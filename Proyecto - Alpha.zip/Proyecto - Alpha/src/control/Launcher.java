package control;

import view.VentanaGrafica;
import view.VentanaLog;
import view.VentanaPrincipal;

public class Launcher 
{
	static ControladorPrincipal cpi;
	static ControladorAñadirPuntos cap;
	static ControladorGrafica cg;
	static ControladorColorChooser ccc;
	static ControladorAyuda			ca;
	static ControladorEstadisticas ce;
	static ControladorGuardarPuntos cgp;
	public static ControladorPrincipal getCpi() {
		return cpi;
	}

	public static ControladorAñadirPuntos getCap() {
		return cap;
	}
	public static ControladorGrafica getCg()
	{
		return cg;
	}
	
	public static ControladorAyuda getCa() {
		return ca;
	}

	public static ControladorEstadisticas getCe() {
		return ce;
	}
	public static ControladorGuardarPuntos getCgp() {
		return cgp;
	}
	static VentanaPrincipal ventana;
	static VentanaGrafica ventanaG;
	static VentanaLog	  ventanaLog;
	
	public static VentanaPrincipal getVentana()
	{
		return ventana;
	}

	public static VentanaGrafica getVentanaG()
	{
		return ventanaG;
	}
	
	public static VentanaLog getVentanaLog()
	{
		return ventanaLog;
	}

	public static void main(String[] args) 
	{
		cpi						 = new ControladorPrincipal();
		cap						 = new ControladorAñadirPuntos();
		ccc						 = new ControladorColorChooser();
		cg						 = new ControladorGrafica(ccc);
		ca						 = new ControladorAyuda();
		ce						 = new ControladorEstadisticas();
		cgp						 = new ControladorGuardarPuntos();
		
		ventana		 = new VentanaPrincipal(cpi);
		ventanaG	 = new VentanaGrafica(cg);
		ventanaLog	 = new VentanaLog();
		
		cg.asignarVentana(ventanaG);
		cpi.asignarVentana(ventana);
		ca.asignarVentana(ventanaLog);
		
		ventana.getContentPane().add(ventanaLog);
		ventana.añadirVentanaGrafica(ventanaG);
		
		ventana.setVisible(true);	
	}

}
