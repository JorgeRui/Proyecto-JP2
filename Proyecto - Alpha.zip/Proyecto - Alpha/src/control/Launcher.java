package control;

import view.VentanaPrincipal;

public class Launcher 
{

	public static void main(String[] args) 
	{
		ControladorPrincipal cpi = new ControladorPrincipal(null);
		VentanaPrincipal ventana = new VentanaPrincipal(cpi);
		ventana.setVisible(true);	
	}

}
