package control;

import view.VentanaPrincipal;

public class Launcher 
{
	static ControladorPrincipal cpi;
	static ControladorA�adirPuntos cap;

	public static ControladorPrincipal getCpi() {
		return cpi;
	}

	public static ControladorA�adirPuntos getCap() {
		return cap;
	}

	public static void main(String[] args) 
	{
		cpi						 = new ControladorPrincipal();
		cap						 = new ControladorA�adirPuntos();
		VentanaPrincipal ventana = new VentanaPrincipal(cpi);
		cpi.asignarVentana(ventana);
		ventana.setVisible(true);	
	}

}
