package control;

import view.VentanaPrincipal;

public class Launcher 
{

	public static void main(String[] args) 
	{
		ControladorPrincipal cpi = new ControladorPrincipal();
		VentanaPrincipal ventana = new VentanaPrincipal(cpi);
		ventana.setVisible(true);	
	}

}
