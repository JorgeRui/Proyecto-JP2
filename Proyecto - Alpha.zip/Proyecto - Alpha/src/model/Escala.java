package model;

import java.util.Vector;
/**
 * Clase que se encarga de traducir valores l�gicos del programa a valores de pixeles
 * @author Jorge Rui Da Silva
 * @version 1.0
 */
public class Escala
{
	//--------- VARIABLES DE LA CLASE ---------
    /** X minima de nuestro gr�fico */
	double xMin;

    /** X m�xima de nuestro gr�fico */
	double xMax;

    /** Y m�nima de nuestro gr�fico */
	double yMin;

    /** Y m�xima de nuestro gr�fico */
	double yMax;

    /** ancho en pixels de nuestra �rea de dibujo */
    int ancho;

    /** alto en pixels de nuestra �rea de dibujo */
    int alto;
    

	/**
	 * M�todo que se encarga de definir los extremos de la funci�n
	 * @param nuevaXMin el valor x m�nimo
	 * @param nuevaXMax el valor x m�ximo
	 * @param nuevaYMin el valor y m�nimo
	 * @param nuevaYMax el valor y m�ximo
	 */
	public void tomarExtremos(double nuevaXMin, double nuevaXMax, double nuevaYMin, double nuevaYMax)
	{
		if (nuevaXMin == nuevaXMax || nuevaYMin == nuevaYMax)
		{
			return;
		}
		
		//Si los valores x estan al rev�s, se guardan dandoles la vuelta
		if (nuevaXMin > nuevaXMax)
		{
			xMin = nuevaXMax;
			xMax = nuevaXMin;
			
		}
		else
		{
			xMin = nuevaXMin;
			xMax = nuevaXMax;
		}
		
		//Si los valores y estan al rev�s, se guardan dandoles la vuelta
		if (nuevaYMin > nuevaYMax)
		{
			yMin = nuevaYMax;
			yMax = nuevaYMin;
			
		}
		else
		{
			yMin = nuevaYMin;
			yMax = nuevaYMax;
		}
	
	}
	/**
	 * Método que se encarga de obtener el valor dónde se va a dibujar la gráfica
	 * @param nuevoAncho el ancho del paintPanel
	 * @param nuevoAlto el alto del PaintPanel
	 */
	public void tomarAreaGrafica(int nuevoAncho, int nuevoAlto)
	{
		if (nuevoAncho < 1 || nuevoAlto < 1)
		{
			return;
		}
		
		ancho 	= nuevoAncho;
		alto 	= nuevoAlto;
	}
	
	/**
	 * Devuelve la x en pixeles del valor l�gico que se le pase
	 * @param x la x l�gica
	 * @return devuelve el valor (en pixeles) del punto
	 */
	public int dameX(double x)
	{
		int xPixel;
		xPixel = (int) ((int)((x-xMin)) / (xMax - xMin) * ancho);
		return xPixel;
	}
	/**
	 * Devuelve la y en pixeles del valor l�gico que se le pase
	 * @param y la y l�gica
	 * @return devuelve el valor (en pixeles) del punto
	 */
	public int dameY(double y)
	{
		int yPixel;
		yPixel = (int)(alto-(y-yMin)/(yMax - yMin) * alto);
		return yPixel;
	}
	/**
	 * Se encarga de devolver la x en pixeles de los valores l�gicos que se les pase
	 * @param x el vector de puntos de x
	 * @param numPuntos el n�mero de puntos que se le pasan
	 * @return devuelve un array con los valores de los pixeles
	 */
	public int[] dameX(Vector<Punto> x, int numPuntos)
	{
		int[] xPixel = new int[x.size()];
		
		double factorConversion;
		if (x == null || xPixel == null || numPuntos < 1)
		{
			System.out.println("Error clase Escala - DameX (Valores NULL)");
			return null;
		}
		factorConversion = ancho / (xMax - xMin);
		
		for (int i = 0; i < numPuntos; i++) 
		{
			xPixel[i] = (int)((x.get(i).getX() - xMin) * factorConversion + ancho/2); //+ ancho/2
		}
		return xPixel;
	}
	/**
	 * Se encarga de devolver la y en pixeles de los valores l�gicos que se les pase
	 * @param y el vector de puntos de y
	 * @param numPuntos el n�mero de puntos que se le pasan
	 * @return devuelve un array con los valores de los pixeles
	 */
	public int[] dameY(Vector<Punto> y, int numPuntos)
	{
		int[] yPixel = new int[y.size()];
		double factorConversion;
		if (y == null || yPixel == null || numPuntos < 1)
		{
			System.out.println("Error clase Escala - DameX (Valores NULL)");
			return null;
		}
		factorConversion = alto / (yMax - yMin);
		
		for (int i = 0; i < numPuntos; i++) 
		{
			yPixel[i] = (int)(alto - (y.get(i).getY() - yMin) * factorConversion);
		}
		return yPixel;
	}

}