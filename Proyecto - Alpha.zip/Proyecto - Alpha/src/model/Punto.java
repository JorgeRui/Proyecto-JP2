package model;

/**
 * Clase que define un punto lógico
 * @author Jorge Da Silva
 * @version 10.0
 */
public class Punto
{
	
	double x, y;
	
	/**
	 * Metodo que permite acceder a x
	 * @return X
	 */
	
	public double getX() 
	{
		return x;
	}

//	
	/**
	 * Metodo que permite acceder a y
	 * @return Y
	 */
	
	public double getY() 
	{
		return y;
	}
	
	/**
	 * Construir el punto con x e y
	 * @param x
	 * @param y
	 */
	
	public Punto(double x, double y)
	{
		this.x = x;
		this.y = y;
	}
	
	
	/**
	 * Metodo que se encarga de mostrar el punto
	 */
	public String toString()
	{
		return " x(" + x + ")" + ", y(" + y + ")";
	}
}
