package model;

public class Punto
{
	
	double x, y;
	
	/**
	 * Metodo que permite acceder a x
	 * @return X
	 */
	
	public double getX() 
	{
		return x;
	}
	
//	/** SE PUEDE QUITAR
//	 * Pasamos los puntos a la ventana mostrar puntos  
//	 * @param x
//	 */
//	
//	public void setX(double x)
//	{
//		this.x = x;
//	}
//	
	/**
	 * Metodo que permite acceder a y
	 * @return Y
	 */
	
	public double getY() 
	{
		return y;
	}
	
//	/**SE PUEDE QUITAR
//	 * 
//	 * @param y
//	 */
//	
//	public void setY(double y) 
//	{
//		this.y = y;
//	}
//	
	/**
	 * Construir el punto con x e y
	 * @param x
	 * @param y
	 */
	
	public Punto(double x, double y)
	{
		this.x = x;
		this.y = y;
	}
	
	/**
	 * 
	 */
	
	public String toString()
	{
		return "x(" + x + ")" + ", y(" + y + ")";
	}
}
