package control;

import view.VentanaPrincipal;

public class Launcher {

	public static void main(String[] args) {

	
			VentanaPrincipal mf = new VentanaPrincipal();
			mf.setVisible(true);	
		
		}

}
