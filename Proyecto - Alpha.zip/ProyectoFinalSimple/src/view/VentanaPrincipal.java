package view;

import java.awt.BorderLayout;
import java.awt.Color;
import java.awt.Container;
import java.awt.GridBagConstraints;
import java.awt.GridBagLayout;


import javax.swing.JButton;
import javax.swing.JCheckBox;
import javax.swing.JFrame;
import javax.swing.JLabel;
import javax.swing.JMenu;
import javax.swing.JMenuBar;
import javax.swing.JMenuItem;
import javax.swing.JPanel;
import javax.swing.JSlider;


public class VentanaPrincipal extends JFrame{
	

	public VentanaPrincipal(){
		
		super("Graficadora");
		setSize(1800,1020);
		setLocationRelativeTo(null);
		
		setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
		
		
		
		JMenuBar menuBar = new JMenuBar();
		this.setJMenuBar(menuBar);
		
		JMenu menuAbrir = new JMenu("Abrir Fichero");
		menuBar.add(menuAbrir);
		JMenuItem menuItemAbrir = new JMenuItem("Abrir...");
		menuAbrir.add(menuItemAbrir);
		//menuItemAbrir.addActionListener(new MenuListener(menuItemAbrir));
		JMenu menuPuntos = new JMenu("Puntos");
		menuBar.add(menuPuntos);
		JMenuItem menuPuntoMostrar = new JMenuItem("Mostrar");
		JMenuItem menuPuntoAnadir = new JMenuItem("Añadir");
		menuPuntos.add(menuPuntoMostrar);
		menuPuntos.add(menuPuntoAnadir);
		
		JMenu menuAyuda = new JMenu("Ayuda");
		menuBar.add(menuAyuda);
		

		PaintPanel paintPanel = new PaintPanel();
		paintPanel.setBackground(Color.WHITE);
		
		JPanel panelEstadistica = new JPanel();
		//panelEstadistica.setBackground(Color.BLUE);
		
		
		
		panelEstadistica.setLayout(new GridBagLayout());
		GridBagConstraints constraints = new GridBagConstraints();
		
		//Boton Calcular Estadistica
		JButton botonEstadistica = new JButton("Calcular estadistica");
		panelEstadistica.add(botonEstadistica);
		
		constraints.gridx = 0;
		constraints.gridy = 0;
		constraints.gridwidth = 1;
		constraints.gridheight = 1;
		panelEstadistica.add (botonEstadistica, constraints);
		
		botonEstadistica.setToolTipText("bla bla1");
		
		// Boton Cambiar
		JButton botonCambiar =new JButton("Cambiar");
		panelEstadistica.add(botonCambiar);
		
		constraints.gridx = 2;
		constraints.gridy = 0;
		constraints.gridwidth = 1;
		constraints.gridheight = 1;
		panelEstadistica.add (botonCambiar, constraints);
		
		botonCambiar.setToolTipText("bla bla2");
		
		//Slider y su etiqueta 
		JSlider slider = new JSlider(JSlider.HORIZONTAL, 0, 30,15);
		JLabel labelSlider = new JLabel("Ejes");
		labelSlider.setOpaque(true);
		slider.setMajorTickSpacing(10);
		slider.setMinorTickSpacing(1);
		slider.setPaintTicks(true);
		slider.setPaintLabels(true);
		panelEstadistica.add(slider);
		panelEstadistica.add(labelSlider);
		
		constraints.gridx = 1;
		constraints.gridy = 0;
		constraints.gridwidth = 1;
		constraints.gridheight = 2;
		panelEstadistica.add (labelSlider, constraints);

		
		constraints.gridx = 1;
		constraints.gridy = 2;
		constraints.gridwidth = 1;
		constraints.gridheight = 2;
		panelEstadistica.add (slider, constraints);
		
		slider.setToolTipText("bla bla2");
		
		//CheckBox Mostrar ejes 
		JCheckBox mostrarEjes = new JCheckBox("Mostrar ejes");
		panelEstadistica.add(mostrarEjes);
		
		constraints.gridx = 1;
		constraints.gridy = 4;
		constraints.gridwidth = 1;
		constraints.gridheight = 2;
		panelEstadistica.add (mostrarEjes, constraints);
		
		mostrarEjes.setToolTipText("bla bla3");
		
		// CheckBox linea de Regresion
		JCheckBox lineaRegresion = new JCheckBox("Mostrar linea de regresion");
		panelEstadistica.add(lineaRegresion);
		
		constraints.gridx = 1;
		constraints.gridy = 6;
		constraints.gridwidth = 1;
		constraints.gridheight = 2;
		panelEstadistica.add (lineaRegresion, constraints);
		
		lineaRegresion.setToolTipText("bla bla4");
		
		// CheckBox MostrarValor
		JCheckBox mostrarValor = new JCheckBox("Mostrar valor");
		panelEstadistica.add(mostrarValor);
		
		constraints.gridx = 1;
		constraints.gridy = 8;
		constraints.gridwidth = 1;
		constraints.gridheight = 1;
		panelEstadistica.add (mostrarValor, constraints);
		
		mostrarValor.setToolTipText("bla bla5");
		
		//Boton MostrarEstadistica
		JButton botonMostrarEstadistica =new JButton("Mostrar estadistica");
		panelEstadistica.add(botonMostrarEstadistica);
		
		constraints.gridx = 1;
		constraints.gridy = 15;
		constraints.gridwidth = 1;
		constraints.gridheight = 15;
		panelEstadistica.add (botonMostrarEstadistica, constraints);
		
		botonMostrarEstadistica.setToolTipText("bla bla6");
		
		
		//CONTENEDOR
		Container contenedor = getContentPane();
		
		
		contenedor.add(paintPanel, BorderLayout.CENTER);	
		contenedor.add(panelEstadistica, BorderLayout.EAST);
	}
	
}
