package view;


import java.awt.Color;

import java.awt.Graphics;

import javax.swing.JPanel;

public class PaintPanel extends JPanel{

	private static final long serialVersionUID = 4175391112773546138L;
	

	@Override
	protected void paintComponent(Graphics g) {
		
		super.paintComponent(g);
		g.setColor(Color.BLACK);
		
		int[] cuadrox = {100, 100, 500, 500};
		int[] cuadroy = {100, 500, 500, 100};
		g.setColor(Color.WHITE);
		g.fillPolygon(cuadrox, cuadroy, 4); 
		
		g.setColor(Color.BLACK);
		g.drawLine(120, 300, 480, 300);
		g.drawLine(300, 120, 300, 480);
		
	
		g.setColor(Color.RED);
		
		
		
	}
}